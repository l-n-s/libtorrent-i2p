#
# core.py
#
# Copyright (C) 2009 Andrew Resch <andrewresch@gmail.com>
#
# Basic plugin template created by:
# Copyright (C) 2008 Martijn Voncken <mvoncken@gmail.com>
# Copyright (C) 2007-2009 Andrew Resch <andrewresch@gmail.com>
#
# Deluge is free software.
#
# You may redistribute it and/or modify it under the terms of the
# GNU General Public License, as published by the Free Software
# Foundation; either version 3 of the License, or (at your option)
# any later version.
#
# deluge is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with deluge.    If not, write to:
# 	The Free Software Foundation, Inc.,
# 	51 Franklin Street, Fifth Floor
# 	Boston, MA  02110-1301, USA.
#
#    In addition, as a special exception, the copyright holders give
#    permission to link the code of portions of this program with the OpenSSL
#    library.
#    You must obey the GNU General Public License in all respects for all of
#    the code used other than OpenSSL. If you modify file(s) with this
#    exception, you may extend this exception to your version of the file(s),
#    but you are not obligated to do so. If you do not wish to do so, delete
#    this exception statement from your version. If you delete this exception
#    statement from all source files in the program, then also delete it here.
#
#

import os

from twisted.internet.utils import getProcessValue

from deluge.log import LOG as log
from deluge.plugins.pluginbase import CorePluginBase
import deluge.component as component
import deluge.configmanager
from deluge.core.rpcserver import export
from deluge.event import DelugeEvent
from deluge.common import windows_check
import time
from deluge._libtorrent import lt as libtorrent

from common import PLUGIN_NAME
from common import MODULE_NAME

CONFIG_FILE = "%s.conf" % MODULE_NAME
ALREADY_ENABLED = False

DEFAULT_CONFIG = {
    "enabled": False,
    "address": "127.0.0.1",
    "router_port": 4444,
    "port": 7656
}

class Core(CorePluginBase):
    def enable(self):
        self.config = deluge.configmanager.ConfigManager(CONFIG_FILE, DEFAULT_CONFIG)
        
    def disable(self):
		self.stop_i2p_router()
		self.config.save()
		deluge.configmanager.close(CONFIG_FILE)
        
    def update(self):
        pass
        
    @export
    def set_config(self, config):
        for key in config.keys():
            self.config[key] = config[key]
        self.config.save()
        
    @export
    def get_config(self):
        return self.config.config
        
    @export
    def start_i2p_router(self,router_address,router_port_spinbutton,port_spinbutton):
        global ALREADY_ENABLED
        session = component.get("Core").session
        if ALREADY_ENABLED == False:
            proxy_settings = libtorrent.proxy_settings()
            settings_obj = libtorrent.session_settings()
            proxy_settings.hostname = router_address
            proxy_settings.port = router_port_spinbutton
            proxy_settings.type = libtorrent.proxy_type.http
            proxy_settings.i2p_tunnel_name = "Deluge"
            session.set_proxy(proxy_settings)
            proxy_settings.port = port_spinbutton
            session.set_i2p_proxy(proxy_settings)
            print "Starting I2P"
            ALREADY_ENABLED = True
            time.sleep(1)
            settings_obj.force_proxy = True
            settings_obj.user_agent = "Deluge"
            settings_obj.report_redundant_bytes = False
            session.set_settings(settings_obj)
            
    @export
    def stop_i2p_router(self):
        global ALREADY_ENABLED
        session = component.get("Core").session
        if ALREADY_ENABLED == True:
            proxy_settings = libtorrent.proxy_settings()
            settings_obj = libtorrent.session_settings()
            proxy_settings.hostname = ""
            proxy_settings.port = 0
            session.set_i2p_proxy(proxy_settings)
            print "Stopping I2P"
            ALREADY_ENABLED = False
            proxy_settings.type = libtorrent.proxy_type.none
            proxy_settings.i2p_tunnel_name = ""
            proxy_settings.port = 0
            session.set_proxy(proxy_settings)
            settings_obj.force_proxy = False
            session.set_settings(settings_obj)
            
