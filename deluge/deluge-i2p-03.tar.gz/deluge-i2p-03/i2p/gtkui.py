#
# gtkui.py
#
# Copyright (C) 2009 Andrew Resch <andrewresch@gmail.com>
#
# Basic plugin template created by:
# Copyright (C) 2008 Martijn Voncken <mvoncken@gmail.com>
# Copyright (C) 2007-2009 Andrew Resch <andrewresch@gmail.com>
#
# Deluge is free software.
#
# You may redistribute it and/or modify it under the terms of the
# GNU General Public License, as published by the Free Software
# Foundation; either version 3 of the License, or (at your option)
# any later version.
#
# deluge is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with deluge.    If not, write to:
# 	The Free Software Foundation, Inc.,
# 	51 Franklin Street, Fifth Floor
# 	Boston, MA  02110-1301, USA.
#
#    In addition, as a special exception, the copyright holders give
#    permission to link the code of portions of this program with the OpenSSL
#    library.
#    You must obey the GNU General Public License in all respects for all of
#    the code used other than OpenSSL. If you modify file(s) with this
#    exception, you may extend this exception to your version of the file(s),
#    but you are not obligated to do so. If you do not wish to do so, delete
#    this exception statement from your version. If you delete this exception
#    statement from all source files in the program, then also delete it here.
#
#

import os
import gtk
import pkg_resources

from deluge.log import LOG as log
from deluge.ui.client import client
from deluge.plugins.pluginbase import GtkPluginBase
import deluge.component as component
import deluge.common

class ExecutePreferences(object):
    def __init__(self, plugin):
        self.plugin = plugin
        self.keys = None
		
    def load(self):
        log.debug("Adding i2p Preferences page")
        self.glade = gtk.glade.XML(self.get_resource("i2p_prefs.glade"))
        self.plugin.add_preferences_page(_("i2p"),
            self.glade.get_widget("i2p_prefs_box"))
        self.plugin.register_hook("on_apply_prefs", self.on_apply_prefs)
        self.plugin.register_hook("on_show_prefs", self.on_show_prefs)
        client.i2p.get_config().addCallback(self.on_get_config)
        
    def unload(self):
		self.plugin.remove_preferences_page(_("i2p"))
		self.plugin.deregister_hook("on_apply_prefs", self.on_apply_prefs)
		self.plugin.deregister_hook("on_show_prefs", self.on_show_prefs)
		
    def get_resource(self, filename):
        return pkg_resources.resource_filename("i2p", os.path.join("data",filename))
		
    def on_apply_prefs(self):
        config = {
            "enabled": self.glade.get_widget("enabled_checkbutton").get_active(),
            "address": self.glade.get_widget("router_address").get_text(),
            "port": self.glade.get_widget("port_spinbutton").get_value_as_int(),
            "router_port": self.glade.get_widget("router_port_spinbutton").get_value_as_int(),
        }
        client.i2p.set_config(config)
		
    def on_show_prefs(self):
        client.i2p.get_config().addCallback(self.on_get_config)
		
    def on_get_config(self, config):
		self.glade.get_widget("enabled_checkbutton").set_active(config["enabled"])
		self.glade.get_widget("router_address").set_text(config["address"])
		self.glade.get_widget("port_spinbutton").set_value(config["port"])
		self.glade.get_widget("router_port_spinbutton").set_value(config["router_port"])
		if config["enabled"] == True:
			client.i2p.start_i2p_router(config["address"],config["router_port"],config["port"])
			status_message = "I2P is enabled"
			component.get("StatusBar").i2pstatus_item.set_text(status_message)
			
		if config["enabled"] == False:
			client.i2p.stop_i2p_router()
			status_message = "I2P is disabled"
			component.get("StatusBar").i2pstatus_item.set_text(status_message)
			
class GtkUI(GtkPluginBase):
	
    def enable(self):
		component.get("StatusBar").i2pstatus_item = component.get("StatusBar").add_item(tooltip=_("I2P Status"))
		self.plugin = component.get("PluginManager")
		self.preferences = ExecutePreferences(self.plugin)
		self.preferences.load()

    def disable(self):
		component.get("StatusBar").remove_item(component.get("StatusBar").i2pstatus_item)
		self.preferences.unload()
		