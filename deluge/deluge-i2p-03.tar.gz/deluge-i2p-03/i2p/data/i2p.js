/*!
 * i2p.js
 *
 * Copyright (c) Damien Churchill 2010 <damoxc@gmail.com>
 *
 * This file is part of Deluge and is licensed under GNU General Public License 3.0, or later, with
 * the additional special exception to link portions of this program with the OpenSSL library.
 * See LICENSE for more details.
 *
 */

/**
 * @class Deluge.ux.preferences.I2PPage
 * @extends Ext.Panel
 */

Ext.ns('Deluge.ux.preferences'); 
 
Deluge.ux.preferences.i2pPage = Ext.extend(Ext.Panel, {

    border: false,
    title: _('i2p'),
    layout: 'fit',
    
   initComponent: function() {
   Deluge.ux.preferences.i2pPage.superclass.initComponent.call(this);

        this.SettingsFset = this.add({
            xtype: 'fieldset',
            border: false,
            title: _('Settings'),
            autoHeight: true,
            defaultType: 'spinnerfield',
            style: 'margin-top: 3px; margin-bottom: 0px; padding-bottom: 0px;',
            autoWidth: true,
            labelWidth: 140
        });
        
       this.enabled_checkbutton = this.SettingsFset.add({
            xtype: 'checkbox',
            fieldLabel: _('Enable I2P/SAM Bridge'),
            name: 'enabled'
        });        

        this.URLRouteraddress = this.add({
            xtype: 'fieldset',
            border: false,
            title: _(''),
            autoHeight: true,
            defaultType: 'textfield',
            style: 'margin-top: 3px; margin-bottom: 0px; padding-bottom: 0px;',
            autoWidth: true,
            labelWidth: 140
        });

        this.router_address = this.URLRouteraddress.add({
            fieldLabel: _('I2P Router address:'),
            labelSeparator: '',
            name: 'address',
            width: '80%'
        });
        
       this.SettingsSamport = this.add({
            xtype: 'fieldset',
            border: false,
            title: _(''),
            autoHeight: true,
            defaultType: 'spinnerfield',
            style: 'margin-top: 3px; margin-bottom: 0px; padding-bottom: 0px;', 
            autoWidth: true,
            labelWidth: 140
        });

        this.port_spinbutton = this.SettingsSamport.add({
            fieldLabel: _('SAM Bridge port:'),
            labelSeparator: '',
            name: 'port',
            value: 7656,
            decimalPrecision: 0,
            width: 80
        });
        
        this.SettingsRouterport = this.add({
            xtype: 'fieldset',
            border: false,
            title: _(''),
            autoHeight: true,
            defaultType: 'spinnerfield',
            style: 'margin-top: 3px; margin-bottom: 0px; padding-bottom: 0px;', 
            autoWidth: true,
            labelWidth: 140
        });

        this.router_port_spinbutton = this.SettingsRouterport.add({
            fieldLabel: _('I2P Router port:'),
            labelSeparator: '',
            name: 'router_port',
            value: 4444,
            decimalPrecision: 0,
            width: 80
        });

        this.on('show', this.updateConfig, this);
        
	},
	
    updateConfig: function() {
        deluge.client.i2p.get_config({
            success: function(config) {
                this.enabled_checkbutton.setValue(config['enabled']);
                this.router_address.setValue(config['address']);
                this.port_spinbutton.setValue(config['port']);
                this.router_port_spinbutton.setValue(config['router_port']);    
            },
            scope: this
        });
           this.controlSAM();
    },	    

    onApply: function() {
        // build settings object
        var config = { }

        config['enabled'] = this.enabled_checkbutton.getValue();
        config['address'] = this.router_address.getValue();
        config['port'] = this.port_spinbutton.getValue();
        config['router_port'] = this.router_port_spinbutton.getValue();

        deluge.client.i2p.set_config(config);
        this.controlSAM();
    },

    onOk: function() {
        this.onApply();
    },
    
    controlSAM: function(){
		if (config["enabled"] == true){  
	        deluge.client.i2p.start_i2p_router(config["address"],config["router_port"],config["port"]);
	        }
	    if (config["enabled"] == false){
	        deluge.client.i2p.stop_i2p_router();
	        }
	}
    
});

Ext.ns('Deluge.plugins');

Deluge.plugins.i2pPlugin = Ext.extend(Deluge.Plugin, {

    name: 'i2p',

    onDisable: function() {
        deluge.preferences.removePage(this.prefsPage);
    },

    onEnable: function() {
        this.prefsPage = deluge.preferences.addPage(new Deluge.ux.preferences.i2pPage());
    }
});
Deluge.registerPlugin('i2p', Deluge.plugins.i2pPlugin);
