<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="gl">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>Sobre qBittorrent</translation>
    </message>
    <message>
        <location filename="../about.ui" line="83"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../about.ui" line="128"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../about.ui" line="216"/>
        <location filename="../about.ui" line="293"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="240"/>
        <location filename="../about.ui" line="281"/>
        <source>Country:</source>
        <translation>País:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="228"/>
        <location filename="../about.ui" line="312"/>
        <source>E-mail:</source>
        <translation>Correo-e:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="262"/>
        <source>Greece</source>
        <translation>Grecia</translation>
    </message>
    <message>
        <location filename="../about.ui" line="341"/>
        <source>Current maintainer</source>
        <translation>Mantedor actual</translation>
    </message>
    <message>
        <location filename="../about.ui" line="354"/>
        <source>Original author</source>
        <translation>Autor orixinal</translation>
    </message>
    <message>
        <location filename="../about.ui" line="408"/>
        <source>Libraries</source>
        <translation>Bibliotecas</translation>
    </message>
    <message>
        <location filename="../about.ui" line="420"/>
        <source>This version of qBittorrent was built against the following libraries:</source>
        <translation>Esta versión de qBittorrent compilouse contra as seguintes bibliotecas:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="184"/>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <location filename="../about.ui" line="378"/>
        <source>Translation</source>
        <translation>Tradución</translation>
    </message>
    <message>
        <location filename="../about.ui" line="395"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../about.ui" line="365"/>
        <source>Thanks to</source>
        <translation>Grazas a</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="29"/>
        <source>Save as</source>
        <translation>Gardar como</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="45"/>
        <source>Set as default save path</source>
        <translation>Estabelecer como ruta predefinida para gardar</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="55"/>
        <source>Never show again</source>
        <translation>Non mostrar de novo</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="72"/>
        <source>Torrent settings</source>
        <translation>Opcións torrent</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="78"/>
        <source>Start torrent</source>
        <translation>Iniciar o torrent</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="90"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="109"/>
        <source>Skip hash check</source>
        <translation>Saltar a comprobación hash</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="119"/>
        <source>Torrent Information</source>
        <translation>Información do torrent</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="127"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="141"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="155"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="246"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="251"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="256"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="261"/>
        <source>Do not download</source>
        <translation>Non descargar</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="74"/>
        <source>Other...</source>
        <comment>Other save path...</comment>
        <translation>Outra...</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="190"/>
        <location filename="../addnewtorrentdialog.cpp" line="625"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="190"/>
        <source>The torrent file does not exist.</source>
        <translation>O ficheiro torrent non existe.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="200"/>
        <source>Invalid torrent</source>
        <translation>Torrent incorrecto</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="200"/>
        <source>Failed to load the torrent: %1</source>
        <translation>Produciuse un fallo ao cargar o torrent: %1</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="206"/>
        <location filename="../addnewtorrentdialog.cpp" line="228"/>
        <source>Already in download list</source>
        <translation>Xa está na lista de descargas.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="206"/>
        <source>Torrent is already in download list. Merging trackers.</source>
        <translation>O torrent xa está na lista de descargas. Combinando localizadores.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="640"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Non dispoñíbel</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="641"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Non dispoñíbel</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="650"/>
        <source>Not available</source>
        <translation>Non dispoñíbel</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="222"/>
        <source>Invalid magnet link</source>
        <translation>Ligazón magnet incorrecta</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="222"/>
        <source>This magnet link was not recognized</source>
        <translation>Non se recoñeceu esta ligazón magnet</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="228"/>
        <source>Magnet link is already in download list. Merging trackers.</source>
        <translation>A ligazón magnet xa está na lista de descargas. Combinando localizadores.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="235"/>
        <source>Magnet link</source>
        <translation>Ligazón magnet</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="247"/>
        <source>Retrieving metadata...</source>
        <translation>Recuperando os metadatos...</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="308"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>Non dispoñíbel</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="310"/>
        <source>Disk space: %1</source>
        <translation>Espazo no disco: %1</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="330"/>
        <location filename="../addnewtorrentdialog.cpp" line="337"/>
        <location filename="../addnewtorrentdialog.cpp" line="339"/>
        <source>Choose save path</source>
        <translation>Seleccionar a ruta onde gardar</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="393"/>
        <source>Rename the file</source>
        <translation>Cambiar o nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="394"/>
        <source>New name:</source>
        <translation>Nome novo:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="398"/>
        <location filename="../addnewtorrentdialog.cpp" line="424"/>
        <source>The file could not be renamed</source>
        <translation>Non foi posíbel cambiar o nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="399"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Este nome de ficheiro contén caracteres prohibidos, escolla un nome diferente.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="425"/>
        <location filename="../addnewtorrentdialog.cpp" line="460"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nome de ficheiro xa existe neste cartafol. Use un nome diferente.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="459"/>
        <source>The folder could not be renamed</source>
        <translation>Non foi posíbel cambiar o nome do cartafol</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="518"/>
        <source>Rename...</source>
        <translation>Cambiar o nome...</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="522"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="619"/>
        <source>Parsing metadata...</source>
        <translation>Analizando os metadatos...</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="623"/>
        <source>Metadata retrieval complete</source>
        <translation>Completouse a recuperación dos metadatos</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="626"/>
        <source>Unknown error</source>
        <translation>Erro descoñecido</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../preferences/advancedsettings.h" line="196"/>
        <source>Disk write cache size</source>
        <translation>Tamaño da caché de escritura no disco</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="177"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="212"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Portos de saída (mín.) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="217"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Portos de saída (máx.) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="223"/>
        <source>Recheck torrents on completion</source>
        <translation>Volver comprobar os torrents ao rematar</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="229"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalo de refresco da lista de transferencias</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="228"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="59"/>
        <source>Setting</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="59"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="175"/>
        <source> (auto)</source>
        <translation> (auto)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="202"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="203"/>
        <source>Disk cache expiry interval</source>
        <translation>Intervalo de caducidade da caché do disco</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="207"/>
        <source>Enable OS cache</source>
        <translation>Activar a caché do SO</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="232"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Mostrar os países dos pares (Geoip)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="235"/>
        <source>Resolve peer host names</source>
        <translation>Mostrar os servidores dos pares</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="240"/>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Número máximo de conexións semi-abertas [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="243"/>
        <source>Strict super seeding</source>
        <translation>Super sementeira estrita</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="263"/>
        <source>Network Interface (requires restart)</source>
        <translation>Interface de rede (necesita reiniciar)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="266"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Escoitar no enderezo IPv6 (precisa reiniciar)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="294"/>
        <source>Exchange trackers with other peers</source>
        <translation>Intercambio de localizadores con outros pares</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="297"/>
        <source>Always announce to all trackers</source>
        <translation>Anunciar sempre a todos os localizadores</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="245"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Calquera interface</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="269"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Enderezo IP que enviar aos localizadores (necesita reiniciar)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="272"/>
        <source>Display program on-screen notifications</source>
        <translation>Mostrar as notificacións na pantalla</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="275"/>
        <source>Enable embedded tracker</source>
        <translation>Activar o localizador integrado</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="280"/>
        <source>Embedded tracker port</source>
        <translation>Porto do localizador integrado</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="283"/>
        <source>Check for software updates</source>
        <translation>Comprobar se hai actualizacións </translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="287"/>
        <source>Use system icon theme</source>
        <translation>Usar o tema das iconas do sistema</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="291"/>
        <source>Confirm torrent deletion</source>
        <translation>Confirmar a eliminación do torrent</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="220"/>
        <source>Ignore transfer limits on local network</source>
        <translation>Ignorar os límites de transferencia na rede local</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="14"/>
        <source>Automated RSS Downloader</source>
        <translation>Xestor de descargas RSS automático</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable the automated RSS downloader</source>
        <translation>Activar o xestor de descargas RSS automático</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="48"/>
        <source>Download rules</source>
        <translation>Regras de descarga</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="123"/>
        <source>Rule definition</source>
        <translation>Definición da regra</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="138"/>
        <source>Must contain:</source>
        <translation>Debe conter:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="180"/>
        <source>Must not contain:</source>
        <translation>Non debe conter:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="129"/>
        <source>Use regular expressions</source>
        <translation>Usar expresións regulares</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="355"/>
        <source>Import...</source>
        <translation>Importar...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="362"/>
        <source>Export...</source>
        <translation>Exportar...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="233"/>
        <source>Assign label:</source>
        <translation>Asignar etiqueta:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="252"/>
        <source>Save to a different directory</source>
        <translation>Gardar nun cartafol diferente</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="264"/>
        <source>Save to:</source>
        <translation>Gardar en:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="308"/>
        <source>Apply rule to feeds:</source>
        <translation>Aplicar a regra ás fontes:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="330"/>
        <source>Matching RSS articles</source>
        <translation>Artigos RSS coincidentes</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="322"/>
        <source>New rule name</source>
        <translation>Nome da regra nova</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="322"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Escriba o nome da regra de descarga nova.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="326"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="444"/>
        <source>Rule name conflict</source>
        <translation>Conflito co nome da regra</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="326"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="444"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Xa existe unha regra con este nome. Escolla un diferente.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="344"/>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Está seguro que desexa eliminar a regra de descarga chamada %1?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="346"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Está seguro que desexa eliminar as regras de descarga seleccionadas?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="347"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmación de eliminación da regra</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="363"/>
        <source>Destination directory</source>
        <translation>Cartafol de destino</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="371"/>
        <source>Invalid action</source>
        <translation>A acción non é válida</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="371"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>A lista está baleira, non hai nada que exportar.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="375"/>
        <source>Where would you like to save the list?</source>
        <translation>Onde desexa gardar a lista?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="375"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Lista de regras (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="380"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="380"/>
        <source>Failed to create the destination file</source>
        <translation>Produciuse un fallo ao crear o cartafol de destino</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="388"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Indique o ficheiro de regras de descarga RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="388"/>
        <source>Rules list</source>
        <translation>Lista de regras</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="392"/>
        <source>Import Error</source>
        <translation>Erro de importación</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="392"/>
        <source>Failed to import the selected rules file</source>
        <translation>Produciuse un fallo ao importar o ficheiro de regras seleccionado</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="403"/>
        <source>Add new rule...</source>
        <translation>Engadir unha regra nova...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="409"/>
        <source>Delete rule</source>
        <translation>Eliminar a regra</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="411"/>
        <source>Rename rule...</source>
        <translation>Cambiar o nome da regra...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="413"/>
        <source>Delete selected rules</source>
        <translation>Eliminar as regras seleccionadas</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="440"/>
        <source>Rule renaming</source>
        <translation>Cambio do nome da regra</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="440"/>
        <source>Please type the new rule name</source>
        <translation>Escriba o nome da regra nova</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="541"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Modo Regex: usa Perl como expresións regulares</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="545"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Modo comodín: pode usar&lt;ul&gt;&lt;li&gt;? para substituír calquera caracter&lt;/li&gt;&lt;li&gt;* para substituír o cero ou máis dun caracter&lt;/li&gt;&lt;li&gt;Espazos en branco úsanse como operador AND&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="547"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Modo comodín: pode usar&lt;ul&gt;&lt;li&gt;? para substituír calquera caracter&lt;/li&gt;&lt;li&gt;* para substituír o cero ou máis dun caracter&lt;/li&gt;&lt;li&gt;| úsase como operador OR&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Xestión das cookies</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Chave</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>As chaves comúns para as cookies son &apos;%1&apos;, &apos;%2&apos;.
Debería obter esta información nas preferencias do navegador.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <location filename="../dnsupdater.cpp" line="178"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>O DNS dinámico actualizouse correctamente.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="182"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Erro de DNS dinámico: o servizo non está dispoñíbel temporalmente, intentarase de novo dentro de 30 minutos.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="192"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Erro de DNS dinámico: o nome do servidor indicado non existe nesta conta específica.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="198"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Erro de DNS dinámico: nome do usuario/contrasinal incorrectos.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Erro de DNS dinámico: o qBittorrent está na lista negra deste servizo, por favor informe deste erro en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Erro de DNS dinámico: o servizo devolveu %1 , por favor informe deste erro en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Erro de DNS dinámico: o nome do usuario foi bloqueado por un abuso.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="236"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Erro de DNS dinámico: o nome do dominio indicado non é correcto.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="248"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Erro de DNS dinámico: o nome do dominio indicado é curto de máis.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Erro de DNS dinámico: o contrasinal indicado é curto de máis.</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../deletionconfirmationdlg.h" line="46"/>
        <source>Are you sure you want to delete &quot;%1&quot; from the transfer list?</source>
        <comment>Are you sure you want to delete &quot;ubuntu-linux-iso&quot; from the transfer list?</comment>
        <translation>Está seguro que desexa eliminar «%1» da lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../deletionconfirmationdlg.h" line="48"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Está seguro que desexa eliminar estes %1 torrents da lista de transferencias?</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="../downloadthread.cpp" line="166"/>
        <location filename="../downloadthread.cpp" line="170"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="261"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Non se encontrou o nome do servidor remoto (nome incorrecto)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="263"/>
        <source>The operation was canceled</source>
        <translation>Cancelouse a operación</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="265"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>O servidor remoto pechou a conexión prematuramente, antes de que se recibise e procesase a resposta completa</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="267"/>
        <source>The connection to the remote server timed out</source>
        <translation>Excedeuse o tempo para conectar co servidor remoto</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="269"/>
        <source>SSL/TLS handshake failed</source>
        <translation>Produciuse un fallo no saúdo do SSL/TLS</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="271"/>
        <source>The remote server refused the connection</source>
        <translation>O servidor remoto rexeitou a conexion</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="273"/>
        <source>The connection to the proxy server was refused</source>
        <translation>O servidor proxy rexeitou a conexión</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="275"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>O servidor proxy pechou a conexión prematuramente</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="277"/>
        <source>The proxy host name was not found</source>
        <translation>Non se encontrou o nome do servidor proxy</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="279"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Excedeuse o tempo para conectar co proxy ou este non respondeu en tempo á solicitude enviada</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="281"/>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>O proxy require autenticación para admitir a solicitude pero non aceptou ningunha das credenciais ofrecidas</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="283"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>Denegouse o acceso ao contido remoto (401)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="285"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Non se permite a operación solicitada no contido remoto</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="287"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>Non se encontrou o contido remoto no servidor (404)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="289"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>O servidor remoto require autenticacion para servir o contido pero non aceptou as credenciais enviadas</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="291"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>A API de acceso á rede non pode responder á solicitude porque o protocolo é descoñecido</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="293"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>A operación solicitada é incorrecta para este protocolo</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="295"/>
        <source>An unknown network-related error was detected</source>
        <translation>Detectouse un erro descoñecido relacionado coa rede</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="297"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Detectouse un erro descoñecido relacionado co proxy</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="299"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Detectouse un erro descoñecido relacionado co contido remoto</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="301"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Detectouse unha interrupción no protocolo</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="303"/>
        <source>Unknown error</source>
        <translation>Erro descoñecido</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../executionlog.ui" line="27"/>
        <source>General</source>
        <translation>Xeral</translation>
    </message>
    <message>
        <location filename="../executionlog.ui" line="33"/>
        <source>Blocked IPs</source>
        <translation>IPs bloqueadas</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation>Fontes RSS</translation>
    </message>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation>Sen ler</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <location filename="../headlessloader.h" line="55"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="56"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Para controlar o qBittorrent acceda á interface web en http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="57"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>O nome do administrador da interface web é: %1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="60"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>O contrasinal do administrador da interface web é aínda o predefinido: %1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="61"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Isto é un risco de seguranza, debería cambiar o seu contrasinal nas preferencias do programa.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <location filename="../webui/httpconnection.cpp" line="195"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>A súa IP foi bloqueada despois de varios fallos de autenticación.</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/httpserver.cpp" line="110"/>
        <source>File</source>
        <translation>Ficheiro</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="111"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="112"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="113"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Descargar os torrents desde un URL ou ligazón Magnet</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="114"/>
        <source>Only one link per line</source>
        <translation>Só unha ligazón por liña</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="115"/>
        <source>Download local torrent</source>
        <translation>Descargar un torrent local</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="116"/>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Os ficheiros torrent engadíronse correctamente á lista de descargas.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="117"/>
        <source>Point to torrent file</source>
        <translation>Indicar o ficheiro torrent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="118"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="119"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Está seguro que desexa eliminar os torrents seleccionados da lista e do disco?</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="120"/>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>O límite da velocidade de descarga ten que ser superior a 0 ou debe desactivalo.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="121"/>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>O límite da velocidade de envío ten que ser superior a 0 ou debe desactivalo.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="122"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>O límite do número máximo de conexións ten que ser superior a 0 ou debe desactivalo.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="123"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>O límite do número máximo de conexións por torrent ten que ser superior a 0 ou debe desactivalo.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="124"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>O límite do número máximo de slots de envío por torrent ten que ser superior a 0 ou debe desactivalo.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="125"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Non foi posíbel gardar as preferencias do programa, probabelmente o qBittorrent estea inaccesíbel.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="126"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="127"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="128"/>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>O porto usado para as conexións entrantes debe ser superior ao 1024 e inferior ao 65535.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="129"/>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>O porto usado para a interface web debe ser superior ao 1024 e inferior ao 65535.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="130"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>O nome de usuario da interface web debe ter polo menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="131"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>O contrasinal da interface web debe ter polo menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="132"/>
        <source>Save</source>
        <translation>Gardar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="133"/>
        <source>qBittorrent client is not reachable</source>
        <translation>O cliente qBittorrent non está accesíbel</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="134"/>
        <source>HTTP Server</source>
        <translation>Servidor HTTP</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="135"/>
        <source>The following parameters are supported:</source>
        <translation>Os seguintes parámetros son compatíbeis:</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="136"/>
        <source>Torrent path</source>
        <translation>Ruta ao torrent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="137"/>
        <source>Torrent name</source>
        <translation>Nome do torrent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="138"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>O qBittorrent foi pechado.</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <location filename="../main.cpp" line="109"/>
        <source>Legal Notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="110"/>
        <location filename="../main.cpp" line="121"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent é un programa para compartir ficheiros. Cando descarga un torrent os seus datos son visíbeis para outros . Calquera contido que comparta é da súa única responsabilidade.

Non se mostrarán máis avisos.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="111"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Prema a tecla %1 para aceptar e continuar...</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="122"/>
        <source>Legal notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="123"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="124"/>
        <source>I Agree</source>
        <translation>Acepto</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../lineedit/src/lineedit.cpp" line="30"/>
        <source>Clear the text</source>
        <translation>Borrar o texto</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../loglistwidget.cpp" line="47"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../loglistwidget.cpp" line="48"/>
        <source>Clear</source>
        <translation>Limpar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="37"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="61"/>
        <source>&amp;Tools</source>
        <translation>Ferramen&amp;tas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="82"/>
        <source>&amp;File</source>
        <translation>&amp;Ficheiro</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="50"/>
        <source>&amp;Help</source>
        <translation>&amp;Axuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="91"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="155"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opcións...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="165"/>
        <source>&amp;Resume</source>
        <translation>Continua&amp;r</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="321"/>
        <source>R&amp;esume All</source>
        <translation>Co&amp;ntinuar todo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="194"/>
        <source>Torrent &amp;creator</source>
        <translation>&amp;Crear torrents</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="248"/>
        <location filename="../mainwindow.ui" line="251"/>
        <source>Alternative speed limits</source>
        <translation>Límites alternativos de velocidade</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="259"/>
        <source>Top &amp;tool bar</source>
        <translation>Barra &amp;superior</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="262"/>
        <source>Display top tool bar</source>
        <translation>Mostrar a barra superior</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="270"/>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Velocidade na barra do título</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="273"/>
        <source>Show transfer speed in title bar</source>
        <translation>Mostrar a velocidade de transferencia na barra do título</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="142"/>
        <source>&amp;Add torrent file...</source>
        <translation>Eng&amp;adir un ficheiro torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="147"/>
        <location filename="../mainwindow.ui" line="150"/>
        <source>Exit</source>
        <translation>Saír</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="170"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="175"/>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <source>P&amp;ause All</source>
        <translation>P&amp;ausar todo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="184"/>
        <source>Visit &amp;Website</source>
        <translation>Visitar o sitio &amp;web</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="65"/>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Apagar ao completar as descargas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="189"/>
        <source>Add &amp;link to torrent...</source>
        <translation>Engadir unha &amp;ligazón ao torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="199"/>
        <source>Report a &amp;bug</source>
        <translation>Informar dun &amp;fallo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="204"/>
        <source>Set upload limit...</source>
        <translation>Estabelecer o límite de envío...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Set download limit...</source>
        <translation>Estabelecer o límite de descarga...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="214"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="219"/>
        <source>Set global download limit...</source>
        <translation>Estabelecer o límite global de descarga...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="224"/>
        <source>Set global upload limit...</source>
        <translation>Estabelecer o límite global de envío...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="281"/>
        <source>&amp;RSS reader</source>
        <translation>Lector &amp;RSS</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="289"/>
        <source>Search &amp;engine</source>
        <translation>M&amp;otor de busca</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="345"/>
        <source>Exit qBittorrent</source>
        <translation>Saír do qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="353"/>
        <source>Suspend system</source>
        <translation>Suspender o sistema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="361"/>
        <source>Hibernate system</source>
        <translation>Hibernar o sistema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="369"/>
        <source>Shutdown system</source>
        <translation>Pechar o sistema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="377"/>
        <source>Disabled</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="382"/>
        <location filename="../mainwindow.cpp" line="1268"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="397"/>
        <location filename="../mainwindow.cpp" line="1413"/>
        <source>Check for updates</source>
        <translation>Buscar actualizacións</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="400"/>
        <location filename="../mainwindow.cpp" line="1414"/>
        <source>Check for program updates</source>
        <translation>Buscar actualizacións do programa</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="297"/>
        <source>Lock qBittorrent</source>
        <translation>Bloquear o qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="305"/>
        <source>Import existing torrent...</source>
        <translation>Importar un torrent existente...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="308"/>
        <source>Import torrent...</source>
        <translation>Importar un torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="313"/>
        <source>Donate money</source>
        <translation>Facer unha doazón</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="316"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Se lle gusta o qBittorrent, por favor faga unha doazón!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="334"/>
        <source>Execution &amp;Log</source>
        <translation>&amp;Rexistro de execución</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="337"/>
        <location filename="../mainwindow.cpp" line="1442"/>
        <source>Execution Log</source>
        <translation>Rexistro de execución</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Decrease priority</source>
        <translation>Disminuír a prioridade</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="237"/>
        <source>Increase priority</source>
        <translation>Aumentar a prioridade</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="157"/>
        <source>Set the password...</source>
        <translation>Estabelecer o contrasinal...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="159"/>
        <location filename="../mainwindow.cpp" line="423"/>
        <source>Clear the password</source>
        <translation>Limpar o contrasinal</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="194"/>
        <source>Transfers</source>
        <translation>Transferencias</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <source>Torrent file association</source>
        <translation>Asociación cos ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="321"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent non é o aplicativo predefinido para abrir os ficheiros torrent nin as ligazóns Magnet
Desexa asociar o qBittorrent aos ficheiros torrent e ás ligazóns Magnet?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="408"/>
        <location filename="../mainwindow.cpp" line="434"/>
        <location filename="../mainwindow.cpp" line="701"/>
        <source>UI lock password</source>
        <translation>Contrasinal de bloqueo da interface</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="408"/>
        <location filename="../mainwindow.cpp" line="434"/>
        <location filename="../mainwindow.cpp" line="701"/>
        <source>Please type the UI lock password:</source>
        <translation>Escriba un contrasinal para bloquear a interface:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="412"/>
        <source>The password should contain at least 3 characters</source>
        <translation>O contrasinal debe conter cando menos 3 caracteres</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="418"/>
        <source>Password update</source>
        <translation>Actualizar o contrasinal</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="418"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>O contrasinal de bloqueo da interface actualizouse correctamente</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="423"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Está certo de limpar o contrasinal?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="450"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="466"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="476"/>
        <source>Transfers (%1)</source>
        <translation>Transferencias (%1)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="552"/>
        <source>Download completion</source>
        <translation>FInalización da descarga</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="552"/>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>Finalizou a descarga de %1.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="558"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="558"/>
        <source>An I/O error occurred for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Produciuse un erro de E/S no torrent %1
Razón: %2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="615"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmación de descarga recursiva</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="615"/>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>O torrent %1 contén ficheiros torrent, desexa continuar coa descarga?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="616"/>
        <location filename="../mainwindow.cpp" line="797"/>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="617"/>
        <location filename="../mainwindow.cpp" line="796"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="618"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="632"/>
        <source>Url download error</source>
        <translation>Erro na descarga desde o Url</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="632"/>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Non foi posíbel descargar o ficheiro desde o Url: %1, razón: %2.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="643"/>
        <source>Global Upload Speed Limit</source>
        <translation>Límite global de velocidade de envío</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="662"/>
        <source>Global Download Speed Limit</source>
        <translation>Límite global de velocidade de descarga</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1171"/>
        <source>[D: %1/s, U: %2/s] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[D: %1/s, E: %2/s] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1353"/>
        <source>Missing Python Interpreter</source>
        <translation>Falta o intérprete de Python</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1354"/>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Precísase Python 2.x para usar o motor de busca pero non parece que estea instalado.
Desexa instalalo agora?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1398"/>
        <source>A new version is available</source>
        <translation>Hai dispoñíbel unha nova versión</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1399"/>
        <source>A new version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Hai dispoñíbel unha nova versión de qBittorrent en Sourceforge.
Desexa actualizar o qBittorrent á versión %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1408"/>
        <source>There isn&apos;t a new version available</source>
        <translation>Non hai dispoñíbel ningunha nova versión</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1409"/>
        <source>There isn&apos;t a new version of qBittorrent available on Sourceforge</source>
        <translation>Non hai ningunha nova versión dispoñíbel en Sourceforge</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1510"/>
        <source>Checking for updates...</source>
        <translation>Buscando actualizacións...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1511"/>
        <source>Already checking for program updates in the background</source>
        <translation>Xa se están buscando actualizacións do programa en segundo plano</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1575"/>
        <source>Download error</source>
        <translation>Erro de descarga</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1575"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Non foi posíbel descargar a configuración de Python, razón:%1.
Instálea manualmente.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="412"/>
        <location filename="../mainwindow.cpp" line="714"/>
        <source>Invalid password</source>
        <translation>Contrasinal incorrecto</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="714"/>
        <source>The password is invalid</source>
        <translation>O contrasinal é incorrecto</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1268"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="793"/>
        <source>Exiting qBittorrent</source>
        <translation>Saíndo do qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="794"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Estanse transferindo algúns ficheiros.
Está seguro que desexa saír do qBittorrent?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="798"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="950"/>
        <source>Open Torrent Files</source>
        <translation>Abrir os ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="951"/>
        <source>Torrent Files</source>
        <translation>Ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1038"/>
        <source>Options were saved successfully.</source>
        <translation>Os axustes gardáronse correctamente.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1164"/>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Vel. de descarga: %1 KiB/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1160"/>
        <location filename="../mainwindow.cpp" line="1166"/>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Vel. de envío: %1 KiB/s</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <location filename="../properties/peeraddition.h" line="94"/>
        <source>Invalid IP</source>
        <translation>IP incorrecta</translation>
    </message>
    <message>
        <location filename="../properties/peeraddition.h" line="95"/>
        <source>The IP you provided is invalid.</source>
        <translation>A IP indicada é incorrecta.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <location filename="../properties/peerlistdelegate.h" line="64"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="65"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="66"/>
        <source>Port</source>
        <translation>Porto</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="67"/>
        <source>Flags</source>
        <translation>Bandeiras</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="68"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="69"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="70"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="71"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. de descarga</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="72"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. de envío</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="73"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="74"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Enviado</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="160"/>
        <source>Add a new peer...</source>
        <translation>Engadir un par novo...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="169"/>
        <source>Copy IP</source>
        <translation>Copiar a IP</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="171"/>
        <source>Limit download rate...</source>
        <translation>Límite da velocidade de descarga...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="172"/>
        <source>Limit upload rate...</source>
        <translation>Límite da velocidade de envío...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="174"/>
        <source>Ban peer permanently</source>
        <translation>Bloquear este par pemanentemente</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="185"/>
        <location filename="../properties/peerlistwidget.cpp" line="187"/>
        <source>Peer addition</source>
        <translation>Adición de pares</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="185"/>
        <source>The peer was added to this torrent.</source>
        <translation>O par foi engadido a este torrent.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="187"/>
        <source>The peer could not be added to this torrent.</source>
        <translation>Non foi posíbel engadir o par a este torrent.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="218"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Está seguro? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="218"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Está seguro que desexa bloquear permantemente os pares seleccionados?</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="219"/>
        <source>&amp;Yes</source>
        <translation>&amp;Si</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="219"/>
        <source>&amp;No</source>
        <translation>&amp;Non</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="226"/>
        <source>Manually banning peer %1...</source>
        <translation>Bloqueando manualmente o par %1...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="250"/>
        <source>Upload rate limiting</source>
        <translation>Límites da velocidade de envío</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="284"/>
        <source>Download rate limiting</source>
        <translation>Límites da velocidade de descarga</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="471"/>
        <source>interested(local) and choked(peer)</source>
        <translation>interesado(local) e rexeitado(par)</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="477"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>interesado(local) e aceptado(para)</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="486"/>
        <source>interested(peer) and choked(local)</source>
        <translation>interesado(par) e rexeitado(local)</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="492"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>interesado(par) e aceptado(local)</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="500"/>
        <source>optimistic unchoke</source>
        <translation>aceptado optimista</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="507"/>
        <source>peer snubbed</source>
        <translation>par desbotado</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="514"/>
        <source>incoming connection</source>
        <translation>conexión entrante</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="521"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>interesado(local) e aceptado(para)</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="528"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>interesado(par) e aceptado(local)</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="535"/>
        <source>peer from PEX</source>
        <translation>par desde PEX</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="542"/>
        <source>peer from DHT</source>
        <translation>par de DHT</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="549"/>
        <source>encrypted traffic</source>
        <translation>tráfico cifrado</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="556"/>
        <source>encrypted handshake</source>
        <translation>handshake cifrado</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="571"/>
        <source>peer from LSD</source>
        <translation>par desde LSD</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../preferences/options.ui" line="93"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="104"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="115"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="137"/>
        <source>Web UI</source>
        <translation>Interface web</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="148"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="224"/>
        <source>(Requires restart)</source>
        <translation>(Precisa reiniciar)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="258"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Alternar as cores das filas</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="300"/>
        <location filename="../preferences/options.ui" line="326"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Parar o torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="310"/>
        <location filename="../preferences/options.ui" line="336"/>
        <source>No action</source>
        <translation>Sen acción</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="697"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Anexar a extensión !qB aos nomes dos ficheiros incompletos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="800"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar os ficheiros torrent en:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1005"/>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Os seguintes parámetros son compatíbeis:
&lt;ul&gt;
&lt;li&gt;%f: ruta ao torrent&lt;/li&gt;
&lt;li&gt;%n: nome do torrent&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1119"/>
        <source>Connections Limits</source>
        <translation>Límites da conexión</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1272"/>
        <source>Proxy Server</source>
        <translation>Servidor proxy</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1529"/>
        <source>Global Rate Limits</source>
        <translation>Límites globais de velocidade</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1647"/>
        <source>Apply rate limit to uTP connections</source>
        <translation>Aplicar o límite de velocidade ás conexións uTP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1654"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar os límites de velocidade ás sobrecargas do transporte</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1667"/>
        <source>Alternative Global Rate Limits</source>
        <translation>Límites alternativos globais de velocidade </translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1773"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Programar o uso de límites alternativos de velocidade</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2039"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Activar a busca de pares locais (LPD) para encontrar máis pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2051"/>
        <source>Encryption mode:</source>
        <translation>Modo cifrado:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2059"/>
        <source>Prefer encryption</source>
        <translation>Preferir cifrado</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2064"/>
        <source>Require encryption</source>
        <translation>Precisa cifrado</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2069"/>
        <source>Disable encryption</source>
        <translation>Desactivar o cifrado</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2101"/>
        <source> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Máis información&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2144"/>
        <source>Maximum active downloads:</source>
        <translation>Descargas activas máximas:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2164"/>
        <source>Maximum active uploads:</source>
        <translation>Envíos activos máximos:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2184"/>
        <source>Maximum active torrents:</source>
        <translation>Torrents activos máximos:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="533"/>
        <source>When adding a torrent</source>
        <translation>Cando engada un torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="79"/>
        <location filename="../preferences/options.ui" line="82"/>
        <source>Behavior</source>
        <translation>Comportamento</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="188"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="549"/>
        <source>Display torrent content and some options</source>
        <translation>Mostrar o contido do torrent e algunhas opcións</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1055"/>
        <source>Port used for incoming connections:</source>
        <translation>Porto usado para as conexións entrantes:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1075"/>
        <source>Random</source>
        <translation>Aleatorio</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1125"/>
        <source>Global maximum number of connections:</source>
        <translation>Número máximo global de conexións:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1151"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Número máximo de conexións por torrent:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1174"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Número máximo de slots de envío por torrent:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1547"/>
        <location filename="../preferences/options.ui" line="1702"/>
        <source>Upload:</source>
        <translation>Enviar:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1583"/>
        <location filename="../preferences/options.ui" line="1729"/>
        <source>Download:</source>
        <translation>Descargar:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1576"/>
        <location filename="../preferences/options.ui" line="1609"/>
        <location filename="../preferences/options.ui" line="1722"/>
        <location filename="../preferences/options.ui" line="1749"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="767"/>
        <source>Remove folder</source>
        <translation>Eliminar o cartafol</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1817"/>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1872"/>
        <source>Every day</source>
        <translation>Todos os días</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1877"/>
        <source>Week days</source>
        <translation>Días de entresemana</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1882"/>
        <source>Week ends</source>
        <translation>Fins de semana</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1982"/>
        <source>DHT port:</source>
        <translation>Porto DHT:</translation>
    </message>
    <message utf8="true">
        <location filename="../preferences/options.ui" line="2023"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Clientes de bittorrent compatíbeis co intercambio de pares (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1314"/>
        <source>Host:</source>
        <translation>Servidor:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1293"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1280"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="20"/>
        <location filename="../preferences/options.ui" line="1631"/>
        <source>Options</source>
        <translation>Opcións</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="274"/>
        <source>Action on double-click</source>
        <translation>Acción co dobre clic</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="283"/>
        <source>Downloading torrents:</source>
        <translation>Descargando os torrents:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="305"/>
        <location filename="../preferences/options.ui" line="331"/>
        <source>Open destination folder</source>
        <translation>Abrir o cartafol de destino</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="318"/>
        <source>Completed torrents:</source>
        <translation>Torrents completados:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="350"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="363"/>
        <source>Show splash screen on start up</source>
        <translation>Mostrar a pantalla de presentación ao iniciar</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="373"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar o qBittorrent minimizado</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="399"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimizar o qBittorrent á area de notificación</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="409"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Pechar o qBittorrent á área de notificación</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="418"/>
        <source>Tray icon style:</source>
        <translation>Estilo da icona da bandexa:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="426"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="431"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monocromo (tema escuro)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="436"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monocromo (tema claro)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="380"/>
        <source>Ask for program exit confirmation</source>
        <translation>Pedir a confirmación de saída do programa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="196"/>
        <source>User Interface Language:</source>
        <translation>Idioma da interface do usuario:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="252"/>
        <source>Transfer List</source>
        <translation>Lista de transferencias</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="356"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Iniciar qBittorrent cando se inicie Windows</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="390"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Mostrar o qBittorrent na área de notificacións</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="449"/>
        <source>File association</source>
        <translation>Asociación de ficheiro</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="455"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Usar o qBittorrent para ficheiros .torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="462"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Usar o qBittorrent para ligazóns magnet</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="475"/>
        <source>Power Management</source>
        <translation>Xestión de enerxía</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="481"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Inhibir a suspensión do sistema cando haxa torrents activos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="542"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Non iniciar a descarga automaticamente</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="558"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Traer ao primeiro plano o diálogo torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="580"/>
        <source>Hard Disk</source>
        <translation>Disco ríxido</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="586"/>
        <source>Save files to location:</source>
        <translation>Gardar os ficheiros na localización:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="634"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Anexar a etiqueta do torrent á ruta onde se garda</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="644"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-asignar o espazo no disco a todos os ficheiros</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="651"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Manter os torrents incompletos en:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="704"/>
        <source>Automatically add torrents from:</source>
        <translation>Engadir automaticamente os torrents desde:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="757"/>
        <source>Add folder...</source>
        <translation>Engadir un cartafol...</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="849"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar os ficheiros torrent das descargas rematadas a:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="905"/>
        <source>Email notification upon download completion</source>
        <translation>Enviar un correo-e ao rematar a descarga</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="919"/>
        <source>Destination email:</source>
        <translation>Correo-e de destino:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="929"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="978"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Este servidor require unha conexión segura (SSL)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="990"/>
        <source>Run an external program on torrent completion</source>
        <translation>Executar un programa externo ao rematar o torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1047"/>
        <source>Listening Port</source>
        <translation>Porto de escoita</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1097"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar un porto UPnP / NAT-PMP para reencamiñar desde o router</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1107"/>
        <source>Use different port on each startup</source>
        <translation>Usar un porto distinto en cada inicio</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1233"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Número máximo global de slots de envío:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1368"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Doutro xeito, o servidor proxy usarase unicamente para conexións co localizador</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1371"/>
        <source>Use proxy for peer connections</source>
        <translation>Usar o proxy para conexións cos pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1443"/>
        <source>IP Filtering</source>
        <translation>Filtrado de IPs</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1484"/>
        <source>Reload the filter</source>
        <translation>Recargar o filtro</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1637"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Activar a xestión do largo de banda (uTP)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1790"/>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1864"/>
        <source>When:</source>
        <translation>Cando:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1947"/>
        <source>Privacy</source>
        <translation>Privacidade</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1953"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar o DHT (rede descentralizada) para encontrar máis pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1962"/>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Usar un porto diferente para DHT e BitTorrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2026"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Activar o intercambio de pares (PeX) para buscar máis pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2036"/>
        <source>Look for peers on your local network</source>
        <translation>Buscar pares na súa rede local</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2094"/>
        <source>Enable anonymous mode</source>
        <translation>Activar o modo anónimo</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2243"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Non ter en conta os torrents lentos nestes límites</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2264"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Sementar os torrents até alcanzar a taxa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2293"/>
        <source>then</source>
        <translation>despois</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2304"/>
        <source>Pause them</source>
        <translation>Pausalos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2309"/>
        <source>Remove them</source>
        <translation>Eliminalos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2407"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Usar un porto UPnP / NAT-PMP para reencamiñar desde o router</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2417"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Usar HTTPS no canto de HTTP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2460"/>
        <source>Import SSL Certificate</source>
        <translation>Importar o certificado SSL</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2513"/>
        <source>Import SSL Key</source>
        <translation>Importar a chave SSL</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2448"/>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2501"/>
        <source>Key:</source>
        <translation>Chave:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2535"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Información sobre certificados&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2580"/>
        <source>Bypass authentication for localhost</source>
        <translation>Omitir a autenticación no localhost</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2604"/>
        <source>Update my dynamic domain name</source>
        <translation>Actualizar o nome do dominio dinámico</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2616"/>
        <source>Service:</source>
        <translation>Servizo:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2639"/>
        <source>Register</source>
        <translation>Rexistro</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2648"/>
        <source>Domain name:</source>
        <translation>Nome do dominio:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1288"/>
        <source>(None)</source>
        <translation>(Ningún)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="126"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1303"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1340"/>
        <location filename="../preferences/options.ui" line="2372"/>
        <source>Port:</source>
        <translation>Porto:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="939"/>
        <location filename="../preferences/options.ui" line="1381"/>
        <location filename="../preferences/options.ui" line="2548"/>
        <source>Authentication</source>
        <translation>Autenticación</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="951"/>
        <location filename="../preferences/options.ui" line="1395"/>
        <location filename="../preferences/options.ui" line="2587"/>
        <location filename="../preferences/options.ui" line="2662"/>
        <source>Username:</source>
        <translation>Nome do usuario:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="961"/>
        <location filename="../preferences/options.ui" line="1415"/>
        <location filename="../preferences/options.ui" line="2594"/>
        <location filename="../preferences/options.ui" line="2676"/>
        <source>Password:</source>
        <translation>Contrasinal:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2129"/>
        <source>Torrent Queueing</source>
        <translation>Colocar na cola</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2253"/>
        <source>Share Ratio Limiting</source>
        <translation>Limites da taxa de compartición</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2358"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Activar a interface de usuario web (control remoto)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1298"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1455"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta do filtro (.dat, .p2p, .p2b):</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../previewselect.cpp" line="51"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="52"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="53"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="80"/>
        <location filename="../previewselect.cpp" line="117"/>
        <source>Preview impossible</source>
        <translation>A previsualización non é posíbel</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="80"/>
        <location filename="../previewselect.cpp" line="117"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Sentímolo, non se pode previsualizar este ficheiro</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../properties/proplistdelegate.h" line="108"/>
        <source>Not downloaded</source>
        <translation>Non descargado</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="117"/>
        <location filename="../properties/proplistdelegate.h" line="162"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="111"/>
        <location filename="../properties/proplistdelegate.h" line="163"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="105"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixta</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="114"/>
        <location filename="../properties/proplistdelegate.h" line="164"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../properties/proptabbar.cpp" line="45"/>
        <source>General</source>
        <translation>Xeral</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="50"/>
        <source>Trackers</source>
        <translation>Localizadores</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="54"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="58"/>
        <source>HTTP Sources</source>
        <translation>Fontes HTTP</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="62"/>
        <source>Content</source>
        <translation>Contido</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../properties/propertieswidget.ui" line="346"/>
        <source>Save path:</source>
        <translation>Ruta:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="438"/>
        <source>Torrent hash:</source>
        <translation>Hash do torrent:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="206"/>
        <source>Share ratio:</source>
        <translation>Taxa de compartición:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="77"/>
        <location filename="../properties/propertieswidget.ui" line="223"/>
        <source>Downloaded:</source>
        <translation>Descargado:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="131"/>
        <source>Availability:</source>
        <translation>Dispoñíbel:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="166"/>
        <source>Transfer</source>
        <translation>Transferencia</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="172"/>
        <source>Uploaded:</source>
        <translation>Enviado:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="274"/>
        <source>Wasted:</source>
        <translation>Desbotado:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="189"/>
        <source>UP limit:</source>
        <translation>Límite de envío:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="240"/>
        <source>DL limit:</source>
        <translation>Límite de descarga:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="257"/>
        <source>Connections:</source>
        <translation>Conexións:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="291"/>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tempo en activo:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="308"/>
        <source>Reannounce in:</source>
        <translation>Publicar de novo en:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="334"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="392"/>
        <source>Created on:</source>
        <translation>Creado o:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="481"/>
        <source>Pieces size:</source>
        <translation>Tamaño dos anacos:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="524"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="668"/>
        <source>Torrent content:</source>
        <translation>Contido do torrent:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="721"/>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="728"/>
        <source>Select None</source>
        <translation>Non seleccionar nada</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="761"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="766"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="771"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="776"/>
        <location filename="../properties/propertieswidget.ui" line="779"/>
        <source>Do not download</source>
        <translation>Non descargar</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="318"/>
        <location filename="../properties/propertieswidget.cpp" line="319"/>
        <source>this session</source>
        <translation>esta sesión</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="320"/>
        <location filename="../properties/propertieswidget.cpp" line="321"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="324"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>sementado durante %1</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="328"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 máx</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="423"/>
        <location filename="../properties/propertieswidget.cpp" line="449"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="423"/>
        <source>This file does not exist yet.</source>
        <translation>Este ficheiro aínda non existe.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="449"/>
        <source>This folder does not exist yet.</source>
        <translation>Este cartafol aínda non existe.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="462"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="463"/>
        <source>Open Containing Folder</source>
        <translation>Abrir o cartafol que o contén</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="464"/>
        <source>Rename...</source>
        <translation>Cambiar o nome...</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="473"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="519"/>
        <source>New Web seed</source>
        <translation>Nova semente web</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="525"/>
        <source>Remove Web seed</source>
        <translation>Retirar semente web</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="527"/>
        <source>Copy Web seed URL</source>
        <translation>Copiar URL da semente web</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="528"/>
        <source>Edit Web seed URL</source>
        <translation>Editar URL da semente web</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="553"/>
        <source>Rename the file</source>
        <translation>Cambiar o nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="554"/>
        <source>New name:</source>
        <translation>Nome novo:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="558"/>
        <location filename="../properties/propertieswidget.cpp" line="589"/>
        <source>The file could not be renamed</source>
        <translation>Non foi posíbel cambiar o nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="559"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Este nome de ficheiro contén caracteres prohibidos, escolla un nome diferente.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="590"/>
        <location filename="../properties/propertieswidget.cpp" line="628"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nome de ficheiro xa existe neste cartafol. Use un nome diferente.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="627"/>
        <source>The folder could not be renamed</source>
        <translation>Non foi posíbel cambiar o nome do cartafol</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="666"/>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Nova semente desde un url</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="667"/>
        <source>New url seed:</source>
        <translation>Nova semente desde un url:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="728"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="673"/>
        <location filename="../properties/propertieswidget.cpp" line="729"/>
        <source>This url seed is already in the list.</source>
        <translation>Esta semente desde un url xa está na lista.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="721"/>
        <source>Web seed editing</source>
        <translation>Edición da semente web</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="722"/>
        <source>Web seed URL:</source>
        <translation>URL da semente web:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="240"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="246"/>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 alcanzou a taxa máxima estabelecida.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="241"/>
        <source>Removing torrent %1...</source>
        <translation>Eliminando o torrent %1...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="247"/>
        <source>Pausing torrent %1...</source>
        <translation>Pausando o torrent %1...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="413"/>
        <source>HTTP user agent is %1</source>
        <translation>O axente do usuario HTTP é %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="443"/>
        <source>Anonymous mode [ON]</source>
        <translation>Modo anómino [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="445"/>
        <source>Anonymous mode [OFF]</source>
        <translation>Modo anómino [APAGADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="503"/>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Enviando o enderezo IP %1 aos localizadores...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="555"/>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Soporte DHT [ACTIVADO], porto: UDP/%1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="557"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="561"/>
        <source>DHT support [OFF]</source>
        <translation>Soporte DHT  [APAGADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="565"/>
        <source>PeX support [ON]</source>
        <translation>Soporte PeX [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="567"/>
        <source>PeX support [OFF]</source>
        <translation>Soporte PeX [APAGADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="570"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>É necesario reiniciar para cambiar o soporte PeX</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="578"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Soporte para busca de pares locais (LPD) [APAGADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="590"/>
        <source>Encryption support [ON]</source>
        <translation>Soporte de cifrado [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="595"/>
        <source>Encryption support [FORCED]</source>
        <translation>Soporte de cifrado [FORZADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="600"/>
        <source>Encryption support [OFF]</source>
        <translation>Soporte de cifrado [APAGADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="662"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Localizador integrado [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="664"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Produciuse un fallo ao iniciar o localizador integrado!</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="667"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Localizador integrado [APAGADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="721"/>
        <source>The Web UI is listening on port %1</source>
        <translation>A interface web está escoitando no porto %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="723"/>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Erro na interface de usuario web - Non é posíbel conectar a interface web ao porto %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="875"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; eliminouse da lista de transferencias e do disco duro.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="877"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; eliminouse da lista de transferencias.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="972"/>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos;non é un URI magnet correcto.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="988"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1144"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1149"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1151"/>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos;xa está na lista de descargas.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1278"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1283"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>Retomouse &apos;%1&apos; (continuación rápida)</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1817"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; foi bloqueado</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1819"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; foi bloqueado</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2008"/>
        <source>qBittorrent is trying to listen on any interface port: TCP/%1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent tenta escoitar en calquera porto da interface: TCP/%1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2024"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent fallou ao escoitar en todos os portos da interface: %1. Razón: %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2050"/>
        <source>qBittorrent is trying to listen on interface %1 port: TCP/%2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent tenta escoitar no porto da interface %1 : TCP/%2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2054"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent non atopou un enderezo local %1 no que escoitar</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2527"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>Non foi posíbel mover o torrent: «%1». Razón: %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2532"/>
        <source>Attempting to move torrent: &apos;%1&apos; to path: &apos;%2&apos;.</source>
        <translation>Tentando mover o torrent: «%1» á ruta: «%2».</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2719"/>
        <source>qBittorrent is successfully listening on interface %1 port: TCP/%2</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent escoita correctamente no porto da interface %1 : TCP/%2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2732"/>
        <source>qBittorrent failed listening on interface %1 port: TCP/%2. Reason: %3</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use</comment>
        <translation>qBittorrent fallou ao escoitar no porto da interface %1 : TCP/%2. Razón: %3</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2762"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP externa: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="3019"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Analizouse correctamente o filtro IP indicado: aplicáronse %1 regras.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="3025"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Erro: produciuse un fallo ao analizar o filtro IP indicado.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1069"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1280"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1285"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>Engadiuse %1 á lista de descargas.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="404"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Soporte UPnP / NAT-PMP [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="407"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Soporte UPnP / NAT-PMP [APAGADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="575"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Soporte para busca de pares locais (LPD) [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1112"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1120"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1122"/>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Non foi posíbel decodificar o ficheiro torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1126"/>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Este ficheiro está corrupto ou non é un torrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1167"/>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Erro: o torrent %1 non contén ningún ficheiro.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1410"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1438"/>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Aviso: engadíronse novos localizadores ao torrent existente.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1468"/>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Aviso: engadíronse novas sementes URL ao torrent existente.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2033"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>A interface indicada para a rede non é válida: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2236"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2238"/>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Descarga recursiva do ficheiro %1 integrado no torrent %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2322"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2324"/>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Non foi posíbel decodificar o ficheiro torrent %1.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2272"/>
        <source>Torrent name: %1</source>
        <translation>Nome do torrent: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2273"/>
        <source>Torrent size: %1</source>
        <translation>Tamaño do torrent: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2274"/>
        <source>Save path: %1</source>
        <translation>Ruta onde gardar: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2275"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>O torrent descargouse en %1.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2276"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Grazas por usar o qBittorrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2279"/>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 rematou a descarga</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2593"/>
        <source>An I/O error occurred, &apos;%1&apos; paused.</source>
        <translation>Produciuse un erro de E/S, &apos;%1&apos; pausado.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2594"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2708"/>
        <source>Reason: %1</source>
        <translation>Razón: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2672"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: produciuse un fallo no mapeado, mensaxe: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2677"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: o mapeado do porto foi correcto, mensaxe: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2703"/>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Os tamaños dos ficheiros non coinciden co torrent %1 , pausándoo.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2707"/>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Os datos para a continuación rápida do torrent %1 foron rexeitados, comprobando de novo...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2713"/>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Fallou a semente url encontrada no url: %1, mensaxe: %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2845"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Descargando &apos;%1&apos;, espere...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="31"/>
        <source>New subscription</source>
        <translation>Subscrición nova</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="47"/>
        <location filename="../rss/rss.ui" line="195"/>
        <location filename="../rss/rss.ui" line="198"/>
        <source>Mark items read</source>
        <translation>Marcar como lidos</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="66"/>
        <source>Update all</source>
        <translation>Actualizar todos</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="95"/>
        <source>RSS Downloader...</source>
        <translation>Xestor de descargas RSS...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="102"/>
        <source>Settings...</source>
        <translation>Axustes...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="124"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(dobre-clic para descargar)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="158"/>
        <location filename="../rss/rss.ui" line="161"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="166"/>
        <source>Rename...</source>
        <translation>Cambiar o nome...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="169"/>
        <source>Rename</source>
        <translation>Cambiar o nome</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="174"/>
        <location filename="../rss/rss.ui" line="177"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="182"/>
        <source>New subscription...</source>
        <translation>Subscrición nova...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="187"/>
        <location filename="../rss/rss.ui" line="190"/>
        <source>Update all feeds</source>
        <translation>Actualizar todas as fontes</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="203"/>
        <source>Download torrent</source>
        <translation>Descargar o torrent</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="208"/>
        <source>Open news URL</source>
        <translation>Abrir o URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="213"/>
        <source>Copy feed URL</source>
        <translation>Copiar o URL da fonte</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="218"/>
        <source>New folder...</source>
        <translation>Cartafol novo...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="223"/>
        <source>Manage cookies...</source>
        <translation>Xestionar as cookies...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="63"/>
        <source>Refresh RSS streams</source>
        <translation>Actualizar os fluxos RSS</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../rss/rss_imp.cpp" line="204"/>
        <source>Please type a rss stream url</source>
        <translation>Escriba un url de fluxo rss</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="204"/>
        <source>Stream URL:</source>
        <translation>URL de fluxo:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <location filename="../rss/rss_imp.cpp" line="247"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Está seguro? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <location filename="../rss/rss_imp.cpp" line="248"/>
        <source>&amp;Yes</source>
        <translation>&amp;Si</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <location filename="../rss/rss_imp.cpp" line="248"/>
        <source>&amp;No</source>
        <translation>&amp;Non</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="157"/>
        <source>Please choose a folder name</source>
        <translation>Seleccione un nome de cartafol</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="157"/>
        <source>Folder name:</source>
        <translation>Nome do cartafol:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="157"/>
        <source>New folder</source>
        <translation>Cartafol novo</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="214"/>
        <source>This rss feed is already in the list.</source>
        <translation>A fonte rss xa está na lista.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Esta seguro que desexa eliminar estes elementos da lista?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="247"/>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Esta seguro que desexa eliminar este elemento da lista?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="390"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Escolla un nome novo para esta fonte RSS</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="390"/>
        <source>New feed name:</source>
        <translation>Nome novo da fonte:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="394"/>
        <source>Name already in use</source>
        <translation>O nome xa existe</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="394"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Este nome xa está usado por un elemento, escolla outro.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="570"/>
        <source>Date: </source>
        <translation>Data: </translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="573"/>
        <source>Author: </source>
        <translation>Autor: </translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="622"/>
        <source>Unread</source>
        <translation>Sen ler</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../rss/rssfeed.cpp" line="357"/>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Descargando automaticamente %1 torrent(s) desde %2 fonte(s) RSS...</translation>
    </message>
</context>
<context>
    <name>RssParser</name>
    <message>
        <location filename="../rss/rssparser.cpp" line="458"/>
        <source>Failed to open downloaded RSS file.</source>
        <translation>Fallo na apertura do ficheiro RSS descargado.</translation>
    </message>
    <message>
        <location filename="../rss/rssparser.cpp" line="495"/>
        <source>Invalid RSS feed at %1.</source>
        <translation>Fonte RSS incorrecta en %1.</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Axustes do lector RSS</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Intervalo de actualización de fontes RSS:</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artigos por fonte:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="102"/>
        <source>Watched Folder</source>
        <translation>Cartafol explorado</translation>
    </message>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="103"/>
        <source>Download here</source>
        <translation>Descargar aquí</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="52"/>
        <source>All categories</source>
        <translation>Todas as categorías</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>Movies</source>
        <translation>Películas</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>TV shows</source>
        <translation>Programas de TV</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Games</source>
        <translation>Xogos</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Pictures</source>
        <translation>Imaxes</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="60"/>
        <source>Books</source>
        <translation>Libros</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="154"/>
        <location filename="../searchengine/searchengine.cpp" line="173"/>
        <location filename="../searchengine/searchengine.cpp" line="174"/>
        <location filename="../searchengine/searchengine.cpp" line="435"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="185"/>
        <source>Empty search pattern</source>
        <translation>Patrón de busca baleiro</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="185"/>
        <source>Please type a search pattern first</source>
        <translation>Escriba primeiro o patrón de busca</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="210"/>
        <location filename="../searchengine/searchengine.cpp" line="299"/>
        <source>Results</source>
        <translation>Resultados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="278"/>
        <source>Searching...</source>
        <translation>Buscando...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="280"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="414"/>
        <source>Search Engine</source>
        <translation>Motor de busca</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="414"/>
        <location filename="../searchengine/searchengine.cpp" line="429"/>
        <source>Search has finished</source>
        <translation>A busca rematou</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="420"/>
        <source>An error occurred during search...</source>
        <translation>Produciuse un erro durante a busca...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="418"/>
        <location filename="../searchengine/searchengine.cpp" line="424"/>
        <source>Search aborted</source>
        <translation>Busca cancelada</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="427"/>
        <source>Search returned no results</source>
        <translation>A busca non obtivo resultados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="434"/>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Resultados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="470"/>
        <location filename="../searchengine/searchengine.cpp" line="476"/>
        <source>Unknown</source>
        <translation>Descoñecido</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="55"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="56"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="57"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Sementadores</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="58"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Pares incompletos</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="59"/>
        <source>Search engine</source>
        <translation>Motor de busca</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="40"/>
        <source>Exit confirmation</source>
        <translation>Confirmación de saída</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="41"/>
        <source>Exit now</source>
        <translation>Saír agora</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="44"/>
        <source>Shutdown confirmation</source>
        <translation>Confirmación de peche</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="45"/>
        <source>Shutdown now</source>
        <translation>Pechar agora</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="99"/>
        <source>qBittorrent will now exit unless you cancel within the next %1 seconds.</source>
        <translation>qBittorrent sairá se non o cancela nos próximos %1 segundos.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="102"/>
        <source>The computer will now be switched off unless you cancel within the next %1 seconds.</source>
        <translation>O computador apagarase se non o cancela nos próximos %1 segundos.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="105"/>
        <source>The computer will now go to sleep mode unless you cancel within the next %1 seconds.</source>
        <translation>O computador entrará no modo suspensión se non o cancela nos próximos %1 segundos.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="108"/>
        <source>The computer will now go to hibernation mode unless you cancel within the next %1 seconds.</source>
        <translation>O computador entrará no modo hibernación se non o cancela nos vindeiros %1 segundos.</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../speedlimitdlg.h" line="84"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estadísticas de usuario</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation>Conexións totais con pares:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation>Taxa global:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="50"/>
        <source>Alltime download:</source>
        <translation>Descarga absoluta:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="77"/>
        <source>Alltime upload:</source>
        <translation>Envío absoluto:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="94"/>
        <source>Total waste (this session):</source>
        <translation>Desbotado total (esta sesión):</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="114"/>
        <source>Cache statistics</source>
        <translation>Estadísticas da caché</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="120"/>
        <source>Read cache Hits:</source>
        <translation>Accesos á caché de lectura:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="147"/>
        <source>Total buffers size:</source>
        <translation>Tamaño total dos búferes:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="157"/>
        <source>Performance statistics</source>
        <translation>Estadísticas de rendemento</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="203"/>
        <source>Queued I/O jobs:</source>
        <translation>Traballos na cola E/S:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="210"/>
        <source>Write cache overload:</source>
        <translation>Sobrecarga da caché de escritura:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="217"/>
        <source>Average time in queue (ms):</source>
        <translation>Tempo medio na cola (ms):</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="224"/>
        <source>Read cache overload:</source>
        <translation>Sobrecarga da caché de lectura:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="231"/>
        <source>Total queued size:</source>
        <translation>Tamaño total da cola:</translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="279"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="179"/>
        <source>Connection status:</source>
        <translation>Estado da conexión:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="179"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Non hai conexións directas. Isto pode significar que hai problemas na configuración da rede.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="95"/>
        <location filename="../statusbar.h" line="186"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodos</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="149"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>É necesario reiniciar o qBittorrent</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="159"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>O qBittorrent foi actualizado e necesita reiniciarse para que os cambios sexan efectivos.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="171"/>
        <location filename="../statusbar.h" line="176"/>
        <source>Connection Status:</source>
        <translation>Estado da conexión:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="171"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Desconectado. Isto significa, normalmente, que o programa fallou ao escoitar o porto seleccionado para conexións entrantes.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="176"/>
        <source>Online</source>
        <translation>Conectado</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="192"/>
        <location filename="../statusbar.h" line="193"/>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="203"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Prema para cambiar aos límites alternativos de velocidade</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="199"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Prema para cambiar aos límites normais de velocidade</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="212"/>
        <source>Manual change of rate limits mode. The scheduler is disabled.</source>
        <translation>Cambio manual do modo de límites de velocidade. O programador está desactivado.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="224"/>
        <source>Global Download Speed Limit</source>
        <translation>Límite global de velocidade de descarga</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="249"/>
        <source>Global Upload Speed Limit</source>
        <translation>Límite global de velocidade de envío</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../torrentcontentmodel.cpp" line="41"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../torrentcontentmodel.cpp" line="41"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../torrentcontentmodel.cpp" line="42"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../torrentcontentmodel.cpp" line="42"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="74"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Seleccionar un cartafol para engadir ao torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="90"/>
        <source>Select a file to add to the torrent</source>
        <translation>Seleccionar un ficheiro para engadir ao torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="113"/>
        <source>No input path set</source>
        <translation>Non se estabeleceu unha ruta de entrada</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="113"/>
        <source>Please type an input path first</source>
        <translation>Escriba primeiro unha ruta de entrada</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="123"/>
        <source>Select destination torrent file</source>
        <translation>Seleccionar o destino para o ficheiro torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="123"/>
        <source>Torrent Files</source>
        <translation>Ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="150"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="164"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent creation</source>
        <translation>Crear un torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="150"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>A creación do torrent fallou, razón:%1</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="164"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>O ficheiro torrent creado non é válido. Non será engadido á lista de descargas.</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent was created successfully:</source>
        <translation>O torrent creouse correctamente:</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation>Importación de torrents</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="53"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>O asistente axudárao a compartir co qBittorrent un torrent descargado.</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="65"/>
        <source>Torrent file to import:</source>
        <translation>Ficheiro torrent a importar:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="109"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="90"/>
        <source>Content location:</source>
        <translation>Localización do contido:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="121"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Ignorar o paso de comprobación de datos e sementar inmediatamente</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="131"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="68"/>
        <source>Torrent file to import</source>
        <translation>Ficheiro torrent a importar</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="68"/>
        <source>Torrent files</source>
        <translation>Ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="102"/>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>Ficheiros %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="104"/>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Indique a localización de %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="139"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Indique a localización do torrent: %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="244"/>
        <source>Invalid torrent file</source>
        <translation>Ficheiro torrent incorrecto</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="244"/>
        <source>This is not a valid torrent file.</source>
        <translation>Este non é un ficheiro torrent correcto.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="274"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="276"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="277"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Feito</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="278"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="279"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Sementes</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="280"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="281"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. de descarga</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="282"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. de envío</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="283"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Taxa</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="284"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Tempo restante</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="285"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="286"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Engadido o</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="287"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completado o</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="288"/>
        <source>Tracker</source>
        <translation>Localizador</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="289"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límite de descarga</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="290"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límite de envío</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="291"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="292"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Enviado</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="293"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restante</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="294"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tempo  en activo</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="295"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Gardar a ruta</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="296"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="297"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Límite da taxa</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../properties/trackerlist.cpp" line="64"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="65"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="66"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="67"/>
        <source>Message</source>
        <translation>Mensaxe</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="201"/>
        <location filename="../properties/trackerlist.cpp" line="275"/>
        <source>Working</source>
        <translation>Funcionando</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="202"/>
        <source>Disabled</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="223"/>
        <source>This torrent is private</source>
        <translation>Este torrent é privado</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="279"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="283"/>
        <source>Not working</source>
        <translation>Inactivo</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="286"/>
        <source>Not contacted yet</source>
        <translation>Aínda sen conexión</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="377"/>
        <source>Tracker URL:</source>
        <translation>URL do localizador:</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="377"/>
        <source>Tracker editing</source>
        <translation>Edición do localizador</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="383"/>
        <location filename="../properties/trackerlist.cpp" line="396"/>
        <source>Tracker editing failed</source>
        <translation>Fallou a edición do localizador</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="383"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>A URL introducida para o localizador non é correcta.</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="396"/>
        <source>The tracker URL already exists.</source>
        <translation>A URL do localizador xa existe.</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="426"/>
        <source>Add a new tracker...</source>
        <translation>Engadir un novo localizador...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="432"/>
        <source>Copy tracker url</source>
        <translation>Copiar a url do localizador</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="433"/>
        <source>Edit selected tracker URL</source>
        <translation>Editar a URL do localizador seleccionado</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="438"/>
        <source>Force reannounce to all trackers</source>
        <translation>Forzar outro anuncio en todos os localizadores</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="431"/>
        <source>Remove tracker</source>
        <translation>Eliminar o localizador</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diálogo de adición de localizadores</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista de localizadores a engadir (un por liña):</translation>
    </message>
    <message utf8="true">
        <location filename="../properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>URL da lista compatíbel con µTorrent:</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="79"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="79"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Produciuse un erro mentres se tentaba abrir o ficheiro descargado.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="124"/>
        <source>No change</source>
        <translation>Sen cambios</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="124"/>
        <source>No additional trackers were found.</source>
        <translation>Non se encontraron localizadores novos.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="133"/>
        <source>Download error</source>
        <translation>Erro de descarga</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="133"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Non foi posíbel descargar a lista de localizadores, razón: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../transferlistdelegate.h" line="94"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="97"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Descargando os metadatos</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="100"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Asignando</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="104"/>
        <source>Paused</source>
        <translation>Pausado</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="108"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Na cola</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="112"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sementando</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="115"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Á espera</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="119"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Comprobando</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="122"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>Na cola de comprobación</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="125"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Comprobando os datos para continuar</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="139"/>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="147"/>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="155"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>sementado durante %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../transferlistfilterswidget.h" line="207"/>
        <source>Torrents</source>
        <translation>Torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="213"/>
        <source>Labels</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="227"/>
        <location filename="../transferlistfilterswidget.h" line="309"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="230"/>
        <location filename="../transferlistfilterswidget.h" line="310"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="233"/>
        <location filename="../transferlistfilterswidget.h" line="311"/>
        <source>Completed</source>
        <translation>Completados</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="236"/>
        <location filename="../transferlistfilterswidget.h" line="312"/>
        <source>Paused</source>
        <translation>Pausados</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="239"/>
        <location filename="../transferlistfilterswidget.h" line="313"/>
        <source>Active</source>
        <translation>Activos</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="242"/>
        <location filename="../transferlistfilterswidget.h" line="314"/>
        <source>Inactive</source>
        <translation>Inactivos</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="256"/>
        <location filename="../transferlistfilterswidget.h" line="493"/>
        <source>All labels</source>
        <translation>Todas as etiquetas</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="259"/>
        <location filename="../transferlistfilterswidget.h" line="494"/>
        <source>Unlabeled</source>
        <translation>Sen etiquetar</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="341"/>
        <source>Remove label</source>
        <translation>Eliminar a etiqueta</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="342"/>
        <source>Add label...</source>
        <translation>Engadir unha etiqueta...</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="344"/>
        <source>Resume torrents</source>
        <translation>Continuar os torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="345"/>
        <source>Pause torrents</source>
        <translation>Pausar os torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="346"/>
        <source>Delete torrents</source>
        <translation>Eliminar os torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="372"/>
        <source>New Label</source>
        <translation>Etiqueta nova</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="372"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="377"/>
        <source>Invalid label name</source>
        <translation>O nome da etiqueta non é correcto</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="377"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Non use ningún caracter especial no nome da etiqueta.</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../transferlistwidget.cpp" line="563"/>
        <source>Column visibility</source>
        <translation>Visibilidade da columna</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="813"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="261"/>
        <source>Choose save path</source>
        <translation>Seleccionar unha ruta onde gardar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="485"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límites da velocidade de descarga do torrent</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="518"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límites da velocidade de envío do torrent</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="551"/>
        <source>Recheck confirmation</source>
        <translation>Confirmación da nova comprobación</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="551"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Está seguro que desexa comprobar de novo os torrents seleccionados?</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="638"/>
        <source>New Label</source>
        <translation>Etiqueta nova</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="638"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="643"/>
        <source>Invalid label name</source>
        <translation>O nome da etiqueta non é correcto</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="643"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Non use ningún caracter especial no nome da etiqueta.</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="660"/>
        <source>Rename</source>
        <translation>Cambiar o nome</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="660"/>
        <source>New name:</source>
        <translation>Nome novo:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="698"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Continuar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="700"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="702"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="704"/>
        <source>Preview file...</source>
        <translation>Previsualizar o ficheiro...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="706"/>
        <source>Limit share ratio...</source>
        <translation>Límite da taxa de compartición...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="708"/>
        <source>Limit upload rate...</source>
        <translation>Límite da velocidade de envío...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="710"/>
        <source>Limit download rate...</source>
        <translation>Límite da velocidade de descarga...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="712"/>
        <source>Open destination folder</source>
        <translation>Abrir o cartafol de destino</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="714"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="716"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover abaixo</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="718"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover ao principio</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="720"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover ao final</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="722"/>
        <source>Set location...</source>
        <translation>Estabelecer a localización...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="856"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="724"/>
        <source>Force recheck</source>
        <translation>Forzar outra comprobación</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="726"/>
        <source>Copy magnet link</source>
        <translation>Copiar a ligazón magnet</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="728"/>
        <source>Super seeding mode</source>
        <translation>Modo super-sementeira</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="731"/>
        <source>Rename...</source>
        <translation>Cambiar o nome...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="733"/>
        <source>Download in sequential order</source>
        <translation>Descargar en orde secuencial</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="736"/>
        <source>Download first and last piece first</source>
        <translation>Descargar primeiro os anacos inicial e final</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="814"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nova...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="815"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Restabelecer</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Límites da taxa de Envío/Descarga do torrent</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Usar o límite da taxa global</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="23"/>
        <location filename="../updownratiodlg.ui" line="33"/>
        <location filename="../updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Non estabelecer límite na taxa</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Estabelecer o límite da taxa en</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <location filename="../main.cpp" line="87"/>
        <source>Usage:</source>
        <translation>Utilización:</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="88"/>
        <source>displays program version</source>
        <translation>mostra a versión do programa</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>disable splash screen</source>
        <translation>desactivar a pantalla de presentación</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="92"/>
        <source>run in daemon-mode (background)</source>
        <translation>executar en modo daemon (segundo plano)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="94"/>
        <source>displays this help message</source>
        <translation>mostra esta mensaxe de axuda</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>changes the webui port (current: %1)</source>
        <translation>cambia o porto da interface web (actual: %1)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="96"/>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[ficheiros ou urls]: descarga os torrents indicados polo usuario (opcional)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../about_imp.h" line="54"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar.</source>
        <translation>Un cliente BitTorrent avanzado programado en C++, baseado en QT4 toolkit e libtorrent-rasterbar.</translation>
    </message>
    <message utf8="true">
        <location filename="../about_imp.h" line="56"/>
        <source>Copyright ©2006-2013 The qBittorrent project</source>
        <translation>Dereitos de autor ©2006-2013 The qBittorrent project</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="58"/>
        <source>Home Page: </source>
        <translation>Páxina de inicio:</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="60"/>
        <source>Bug Tracker: </source>
        <translation>Seguimento de fallos:</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="62"/>
        <source>Forum: </source>
        <translation>Foro:</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="65"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent en Freenode</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="82"/>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Desexo dar as grazas ás persoas seguintes que como voluntarios traduciron o qBittorrent:</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="121"/>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Contacte comigo se desexa traducir o qBittorrent ao seu idioma.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <location filename="../properties/peer.ui" line="20"/>
        <source>Peer addition</source>
        <translation>Adición de pares</translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="36"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="59"/>
        <source>Port</source>
        <translation>Porto</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../login.ui" line="14"/>
        <location filename="../login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Autenticación do localizador</translation>
    </message>
    <message>
        <location filename="../login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Localizador:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="86"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../login.ui" line="94"/>
        <source>Username:</source>
        <translation>Nome do usuario:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="117"/>
        <source>Password:</source>
        <translation>Contrasinal:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="154"/>
        <source>Log in</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../login.ui" line="161"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Confirmación de eliminación - &apos;qBittorrent</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Lembrar a elección</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Eliminar tamén os ficheiros do disco duro</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="296"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Ferramenta para a creación de torrents</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="38"/>
        <source>Torrent file creation</source>
        <translation>Crear un ficheiro torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="60"/>
        <source>Add file</source>
        <translation>Engadir un ficheiro</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="67"/>
        <source>Add folder</source>
        <translation>Engadir un cartafol</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="48"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Ficheiro ou cartafol para engadir ao torrent:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="78"/>
        <source>Tracker URLs:</source>
        <translation>URLs do localizador:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="88"/>
        <source>Web seeds urls:</source>
        <translation>URLs das sementes web:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="98"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="127"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Pode separar os grupos / tiers de localizadores cunha liña en branco.</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="148"/>
        <source>Piece size:</source>
        <translation>Tamaño do anaco:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="165"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="170"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="175"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="180"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="185"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="190"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="195"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="200"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="208"/>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="233"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privado (se está activado non se distribuirá na rede DHT)</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="240"/>
        <source>Start seeding after creation</source>
        <translation>Iniciar a sementeira despois da creación</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="250"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorar os límites da taxa de compartición para este torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="289"/>
        <source>Create and save...</source>
        <translation>Crear e gardar...</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="260"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../downloadfromurldlg.ui" line="28"/>
        <source>Add torrent links</source>
        <translation>Engadir ligazóns torrent</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="55"/>
        <source>One per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Un por liña ( acepta ligazóns HTTP, magnet e info-hashes)</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="77"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="84"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Descargar desde urls</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="97"/>
        <source>No URL entered</source>
        <translation>Non se introduciu ningún URL</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="97"/>
        <source>Please type at least one URL.</source>
        <translation>Escriba polo menos un URL.</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Plugins de busca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation>Motores de busca instalados:</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <location filename="../searchengine/engineselect.ui" line="119"/>
        <source>Enabled</source>
        <translation>Activado</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="78"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Pode obter novos plugins con motores de busca aquí: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="93"/>
        <source>Install a new one</source>
        <translation>Instalar un novo</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="100"/>
        <source>Check for updates</source>
        <translation>Buscar actualizacións</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="107"/>
        <source>Close</source>
        <translation>Pechar</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="175"/>
        <source>Uninstall warning</source>
        <translation>Aviso de desinstalación</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="175"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Algúns plugins non se poden desinstalar porque están incluídos no qBittorrent.
Unicamente pode desinstalar os que vostede engada.
Con todo, eses plugins desactiváronse.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="177"/>
        <source>Uninstall success</source>
        <translation>A desinstalación foi correcta</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="338"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>Esta ligazón non semella apuntar a un engadido con motor de busca.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="353"/>
        <source>Select search plugins</source>
        <translation>Seleccionar os plugins de busca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="354"/>
        <source>qBittorrent search plugins</source>
        <translation>Plugins de busca do qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="238"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="263"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="268"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="277"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="280"/>
        <source>Search plugin install</source>
        <translation>Instalación de plugins de busca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="118"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="189"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="300"/>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="121"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="155"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="192"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="303"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="263"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="268"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="277"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="280"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="406"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="439"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="460"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="467"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="238"/>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Xa está instalada unha versión máis recente do plugin co motor de busca %1.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="406"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="439"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="460"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="467"/>
        <source>Search plugin update</source>
        <translation>Actualización do plugin de busca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="439"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="460"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Sentímolo, o servidor de actualizacións non está dispoñíbel temporalmente.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="406"/>
        <source>All your plugins are already up to date.</source>
        <translation>Xa están actualizados todos os plugins.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="263"/>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Non foi posíbel actualizar o plugin co motor de busca %1, mantense a versión antiga.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="268"/>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Non foi posíbel instalar o plugin co motor de busca %1.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="177"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Desistaláronse correctamente todos os plugins seleccionados</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="277"/>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>O plugin co motor de busca %1 actualizouse correctamente.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="280"/>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>O plugin co motor de busca %1 instalouse correctamente.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="338"/>
        <source>Invalid link</source>
        <translation>Ligazón incorrecta</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="467"/>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Sentímolo pero fallou a instalación do plugin de busca %1.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="330"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="339"/>
        <source>New search engine plugin URL</source>
        <translation>URL novo do plugin co motor de busca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="331"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="340"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Información do fallo</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../fs_utils.cpp" line="430"/>
        <location filename="../fs_utils.cpp" line="461"/>
        <location filename="../fs_utils.cpp" line="473"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../misc.cpp" line="76"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="77"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="78"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="79"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="80"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="276"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="421"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="426"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="266"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Descoñecido</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="206"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>O qBittorrent vai apagar o computador porque remataron todas as descargas.</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="412"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 m</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="416"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="246"/>
        <source>Working</source>
        <translation>Funcionando</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="249"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="251"/>
        <source>Not working</source>
        <translation>Inactivo</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="251"/>
        <source>Not contacted yet</source>
        <translation>Aínda sen contactar</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="309"/>
        <location filename="../webui/btjson.cpp" line="310"/>
        <source>this session</source>
        <translation>esta sesión</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="315"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>sementado durante %1</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="317"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 máx</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="385"/>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>D: %1/s - T: %2</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="386"/>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>E: %1/s - T: %2</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1147"/>
        <location filename="../preferences/options_imp.cpp" line="1149"/>
        <source>Choose export directory</source>
        <translation>Seleccionar un cartafol de exportación</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1189"/>
        <location filename="../preferences/options_imp.cpp" line="1191"/>
        <location filename="../preferences/options_imp.cpp" line="1206"/>
        <location filename="../preferences/options_imp.cpp" line="1208"/>
        <source>Choose a save directory</source>
        <translation>Seleccionar un cartafol onde gardar</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1171"/>
        <location filename="../preferences/options_imp.cpp" line="1173"/>
        <source>Choose an ip filter file</source>
        <translation>Seleccionar un ficheiro para os filtros de ip</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1103"/>
        <source>Add directory to scan</source>
        <translation>Engadir un cartafol para explorar</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1109"/>
        <source>Folder is already being watched.</source>
        <translation>O cartafol xa está sendo explorado.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1112"/>
        <source>Folder does not exist.</source>
        <translation>O cartafol non existe.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1115"/>
        <source>Folder is not readable.</source>
        <translation>O cartafol non se pode ler.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1124"/>
        <source>Failure</source>
        <translation>Fallo</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1124"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Produciuse un fallo ao explorar o cartafol &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1171"/>
        <location filename="../preferences/options_imp.cpp" line="1173"/>
        <source>Filters</source>
        <translation>Filtros</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1251"/>
        <source>SSL Certificate</source>
        <translation>Certificado SSL:</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1262"/>
        <source>SSL Key</source>
        <translation>Chave SSL</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1293"/>
        <source>Parsing error</source>
        <translation>Erro de análise</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1293"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Produciuse un fallo ao analizar o filtro Ip indicado</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1295"/>
        <source>Successfully refreshed</source>
        <translation>Actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1295"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Analizouse correctamente o filtro IP indicado: aplicáronse %1 regras.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1373"/>
        <source>Invalid key</source>
        <translation>Chave incorrecta</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1373"/>
        <source>This is not a valid SSL key.</source>
        <translation>Esta non é unha chave SSL correcta.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1388"/>
        <source>Invalid certificate</source>
        <translation>Certificado incorrecto</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1388"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Este non é un certificado SSL correcto.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1397"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>A hora de inicio e de remate teñen que ser distintas.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1400"/>
        <source>Time Error</source>
        <translation>Erro de hora</translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Fonte do plugin</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Fonte do plugin de busca:</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation>Ficheiro local</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation>Ligazón web</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../preview.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Previsualizar a selección</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="38"/>
        <source>File preview</source>
        <translation>Previsualización do ficheiro</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="54"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Os seguintes ficheiros admiten vista previa, seleccione un deles:</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="89"/>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="96"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="31"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="54"/>
        <source>Status:</source>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="78"/>
        <source>Stopped</source>
        <translation>Parado</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="110"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="120"/>
        <source>Go to description page</source>
        <translation>Ir á páxina da descrición</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="140"/>
        <source>Search engines...</source>
        <translation>Motores de busca...</translation>
    </message>
</context>
</TS>
