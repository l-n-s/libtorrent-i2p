<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="hr">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>O programu qBittorrent</translation>
    </message>
    <message>
        <location filename="../about.ui" line="83"/>
        <source>About</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../about.ui" line="128"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../about.ui" line="216"/>
        <location filename="../about.ui" line="293"/>
        <source>Name:</source>
        <translation>Ime:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="240"/>
        <location filename="../about.ui" line="281"/>
        <source>Country:</source>
        <translation>Država:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="228"/>
        <location filename="../about.ui" line="312"/>
        <source>E-mail:</source>
        <translation>E-pošta:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="262"/>
        <source>Greece</source>
        <translation>Grčka</translation>
    </message>
    <message>
        <location filename="../about.ui" line="341"/>
        <source>Current maintainer</source>
        <translation>Trenutni održavatelj</translation>
    </message>
    <message>
        <location filename="../about.ui" line="354"/>
        <source>Original author</source>
        <translation>Začetnik projekta</translation>
    </message>
    <message>
        <location filename="../about.ui" line="408"/>
        <source>Libraries</source>
        <translation>Biblioteke</translation>
    </message>
    <message>
        <location filename="../about.ui" line="420"/>
        <source>This version of qBittorrent was built against the following libraries:</source>
        <translation>Ova verzija qBittorrenta je izgrađena uz sljedeće biblioteke:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="184"/>
        <source>France</source>
        <translation>Francuska</translation>
    </message>
    <message>
        <location filename="../about.ui" line="378"/>
        <source>Translation</source>
        <translation>Prijevod</translation>
    </message>
    <message>
        <location filename="../about.ui" line="395"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../about.ui" line="365"/>
        <source>Thanks to</source>
        <translation>Zahvale</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="29"/>
        <source>Save as</source>
        <translation>Spremi kao</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="45"/>
        <source>Set as default save path</source>
        <translation>Postavi kao uobičajenu putanju spremanja</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="55"/>
        <source>Never show again</source>
        <translation>Ne pokazuj više</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="72"/>
        <source>Torrent settings</source>
        <translation>Postavke torrenta</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="78"/>
        <source>Start torrent</source>
        <translation>Započni torrent</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="90"/>
        <source>Label:</source>
        <translation>Oznaka:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="109"/>
        <source>Skip hash check</source>
        <translation>Preskoči provjeru smjese</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="119"/>
        <source>Torrent Information</source>
        <translation>Informacije o torrentu</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="127"/>
        <source>Size:</source>
        <translation>Veličina:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="141"/>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="155"/>
        <source>Date:</source>
        <translation>Datum:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="246"/>
        <source>Normal</source>
        <translation>Uobičajen</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="251"/>
        <source>High</source>
        <translation>Visok</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="256"/>
        <source>Maximum</source>
        <translation>Najviši</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.ui" line="261"/>
        <source>Do not download</source>
        <translation>Ne preuzimaj</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="74"/>
        <source>Other...</source>
        <comment>Other save path...</comment>
        <translation>Ostali ...</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="190"/>
        <location filename="../addnewtorrentdialog.cpp" line="625"/>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="190"/>
        <source>The torrent file does not exist.</source>
        <translation>Torrent datoteka ne postoji.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="200"/>
        <source>Invalid torrent</source>
        <translation>Neispravan torrent</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="200"/>
        <source>Failed to load the torrent: %1</source>
        <translation>Neuspješno učitavanje torrenta: %1</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="206"/>
        <location filename="../addnewtorrentdialog.cpp" line="228"/>
        <source>Already in download list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="206"/>
        <source>Torrent is already in download list. Merging trackers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="640"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="641"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="650"/>
        <source>Not available</source>
        <translation>Nije dostupan</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="222"/>
        <source>Invalid magnet link</source>
        <translation>Nesispravan magnet link</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="222"/>
        <source>This magnet link was not recognized</source>
        <translation>Ovaj magnet link nije prepoznat</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="228"/>
        <source>Magnet link is already in download list. Merging trackers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="235"/>
        <source>Magnet link</source>
        <translation>Magnet link</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="247"/>
        <source>Retrieving metadata...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="308"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="310"/>
        <source>Disk space: %1</source>
        <translation>Prostor na disku:%1</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="330"/>
        <location filename="../addnewtorrentdialog.cpp" line="337"/>
        <location filename="../addnewtorrentdialog.cpp" line="339"/>
        <source>Choose save path</source>
        <translation>Izaberite putanju spremanja</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="393"/>
        <source>Rename the file</source>
        <translation>Preimenuj datoteku</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="394"/>
        <source>New name:</source>
        <translation>Novo ime:</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="398"/>
        <location filename="../addnewtorrentdialog.cpp" line="424"/>
        <source>The file could not be renamed</source>
        <translation>Datoteku nije moguće preimenovati</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="399"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Ovo ime datoteke sadrži zabranjene znakove. Izaberite druge.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="425"/>
        <location filename="../addnewtorrentdialog.cpp" line="460"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Ime se već koristi u toj mapi. Koristite drugo ime.</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="459"/>
        <source>The folder could not be renamed</source>
        <translation>Mapu nije moguće preimenovati</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="518"/>
        <source>Rename...</source>
        <translation>Preimenuj ...</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="522"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="619"/>
        <source>Parsing metadata...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="623"/>
        <source>Metadata retrieval complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addnewtorrentdialog.cpp" line="626"/>
        <source>Unknown error</source>
        <translation type="unfinished">Nepoznata greška</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../preferences/advancedsettings.h" line="196"/>
        <source>Disk write cache size</source>
        <translation>Veličina privremene memorije pisanja diska</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="177"/>
        <source> MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="212"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Izlazni portovi (Min.) [0: Onemogućeni]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="217"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Izlazni portovi (Maks.) [0: Omogućeni]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="223"/>
        <source>Recheck torrents on completion</source>
        <translation>Ponovno provjeri torrente pri dopunjavanju</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="229"/>
        <source>Transfer list refresh interval</source>
        <translation>Interval osvježavanja popisa transfera</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="228"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="59"/>
        <source>Setting</source>
        <translation>Postavka</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="59"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Vrijednost</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="175"/>
        <source> (auto)</source>
        <translation> (auto)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="202"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="203"/>
        <source>Disk cache expiry interval</source>
        <translation>Interval isteka privremene memorije diska</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="207"/>
        <source>Enable OS cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="232"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Razrješi države peerova (GeoIP)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="235"/>
        <source>Resolve peer host names</source>
        <translation>Razrješi imena peer hostova</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="240"/>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Najveći broj poluotvorenih veza [0: Disabled]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="243"/>
        <source>Strict super seeding</source>
        <translation>Strogo superseedanje</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="263"/>
        <source>Network Interface (requires restart)</source>
        <translation>Mrežno sučelje (zahtjeva ponovno pokretanje)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="266"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="294"/>
        <source>Exchange trackers with other peers</source>
        <translation>Razmjena trackera s drugim peerovima</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="297"/>
        <source>Always announce to all trackers</source>
        <translation>Uvijek obavijesti sve trackere</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="245"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Bilo koje sučelje</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="269"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP adresa za prijaviti trackerima (potrebno ponovno pokretanje)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="272"/>
        <source>Display program on-screen notifications</source>
        <translation>Prikazuj obavijesti.na ekranu</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="275"/>
        <source>Enable embedded tracker</source>
        <translation>Omogući ugrađeni tracker</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="280"/>
        <source>Embedded tracker port</source>
        <translation>Port ugrađenog trackera</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="283"/>
        <source>Check for software updates</source>
        <translation>Provjeri softverska ažuriranja</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="287"/>
        <source>Use system icon theme</source>
        <translation>Koristi teme ikona sustava</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="291"/>
        <source>Confirm torrent deletion</source>
        <translation>Potvrdite brisanje torrenta</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="220"/>
        <source>Ignore transfer limits on local network</source>
        <translation>Zanemari limite transfera na lokalnoj mreži</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="14"/>
        <source>Automated RSS Downloader</source>
        <translation>Automatizirani RSS Preuzimatelj</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable the automated RSS downloader</source>
        <translation>Omogući automatiziranog RSS preuzimatelja</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="48"/>
        <source>Download rules</source>
        <translation>Preuzmi pravila</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="123"/>
        <source>Rule definition</source>
        <translation>Definicija pravila</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="138"/>
        <source>Must contain:</source>
        <translation>Mora sadržavati:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="180"/>
        <source>Must not contain:</source>
        <translation>Ne mora sadržavati:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="129"/>
        <source>Use regular expressions</source>
        <translation>Koristi uobičajene izraze</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="355"/>
        <source>Import...</source>
        <translation>Uvezi ...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="362"/>
        <source>Export...</source>
        <translation>Izvezi ...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="233"/>
        <source>Assign label:</source>
        <translation>Dodijeli oznaku:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="252"/>
        <source>Save to a different directory</source>
        <translation>Spremi u drugi direktorij</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="264"/>
        <source>Save to:</source>
        <translation>Spremi u:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="308"/>
        <source>Apply rule to feeds:</source>
        <translation>Primijeni pravilo na kanal:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="330"/>
        <source>Matching RSS articles</source>
        <translation>Poklapanje RSS članaka</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="322"/>
        <source>New rule name</source>
        <translation>Ime novog pravila</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="322"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Upišite ime novog pravila preuzimanja.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="326"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="444"/>
        <source>Rule name conflict</source>
        <translation>Konflikt imena pravila</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="326"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="444"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Pravilo s tim imenom već postoji. Izaberite drugo ime.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="344"/>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Jeste li sigurni da želite ukloniti pravilo preuzimanja pod pod imenom %1?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="346"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Jeste li sigurni da želite ukloniti odabrana pravila preuzimanja?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="347"/>
        <source>Rule deletion confirmation</source>
        <translation>Pravilo potvrđivanja brisanja</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="363"/>
        <source>Destination directory</source>
        <translation>Odredišni direktorij</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="371"/>
        <source>Invalid action</source>
        <translation>Neispravna radnja</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="371"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Popis je prazan. Nema se što izvesti.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="375"/>
        <source>Where would you like to save the list?</source>
        <translation>Gdje želite spremiti popis?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="375"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Popis pravila (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="380"/>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="380"/>
        <source>Failed to create the destination file</source>
        <translation>Nije uspjelo kreiranje odredišne datoteke</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="388"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Istaknite RSS datoteku pravila preuzimanja</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="388"/>
        <source>Rules list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="392"/>
        <source>Import Error</source>
        <translation>Greška prilikom uvoza</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="392"/>
        <source>Failed to import the selected rules file</source>
        <translation>Nije uspio uvoz datoteke s odabranim pravilima</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="403"/>
        <source>Add new rule...</source>
        <translation>Dodaj novo pravilo...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="409"/>
        <source>Delete rule</source>
        <translation>Izbriši pravilo</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="411"/>
        <source>Rename rule...</source>
        <translation>Preimenuj pravilo ...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="413"/>
        <source>Delete selected rules</source>
        <translation>Izbriši odabrana pravila</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="440"/>
        <source>Rule renaming</source>
        <translation>Preimenovanje pravila</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="440"/>
        <source>Please type the new rule name</source>
        <translation>Upišite ime novog pravila</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="541"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Regex mode: koristi Pearl-u slične uobičajene izraze</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="545"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Wildcard mode: možete koristiti&lt;ul&gt;&lt;li&gt;? za podudaranje s bilo kojim pojedinim znakom&lt;/li&gt;&lt;li&gt;* za podudaranje s nula ili više drugih znakova&lt;/li&gt;&lt;li&gt;Prazna mjesta se računaju kao AND operatori&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="547"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Wildcard mode: možete koristiti&lt;ul&gt;&lt;li&gt;? za podudaranje s bilo kojim pojedinim znakom&lt;/li&gt;&lt;li&gt;* za podudaranje s nula ili više drugih znakova&lt;/li&gt;&lt;li&gt;| se koristi kao OR operator&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Upravljanje kolačićima</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Ključ</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Vrijednost</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Javni ključevi za kolačiće su: &apos;%1&apos;, &apos;%2&apos;.
Ovu informaciju trebate pribaviti iz postavki vašeg web preglednika.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <location filename="../dnsupdater.cpp" line="178"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>Vaš dinamički DNS je uspješno ažuriran.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="182"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Greška dinamičkog DNS-a: Servis je trenutno nedostupan. Novi pokušaj za 30 minuta.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="192"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Greška dinamičkog DNS-a: Dano ime računala ne postoji pod navedenim računom.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="198"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Greška dinamičkog DNS-a: Neispravno korisničko ime ili lozinka.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Greška dinamičkog DNS-a: Servis je qBittorrent stavio na crnu listu. Prijavite grešku na http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Greška dinamičkog DNS-a: Servis je vratio %1. Prijavite grešku na http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Greška dinamičkog DNS-a: Vaše korisničko ime je blokirano zbog zloupotrebe.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="236"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Greška dinamičkog DNS-a: Dano ime domene nije ispravno.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="248"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Greška dinamičkog DNS-a: Dano korisničko ime je prekratko.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Greška dinamičkog DNS-a: Dana lozinka je prekratka.</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../deletionconfirmationdlg.h" line="46"/>
        <source>Are you sure you want to delete &quot;%1&quot; from the transfer list?</source>
        <comment>Are you sure you want to delete &quot;ubuntu-linux-iso&quot; from the transfer list?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../deletionconfirmationdlg.h" line="48"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="../downloadthread.cpp" line="166"/>
        <location filename="../downloadthread.cpp" line="170"/>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="261"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Ime udaljenog računala nije nađeno (neispravno ime računala)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="263"/>
        <source>The operation was canceled</source>
        <translation>Operacija je otkazana</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="265"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Udaljeni poslužitelj je prerano prekinuo spajanje, prije nego je primljen i obrađen cijeli odgovor</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="267"/>
        <source>The connection to the remote server timed out</source>
        <translation>Spajanje s udaljenim poslužiteljem je isteklo</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="269"/>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS usklađivanje nije uspjelo</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="271"/>
        <source>The remote server refused the connection</source>
        <translation>Udaljeni poslužitelj odbija spajanje</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="273"/>
        <source>The connection to the proxy server was refused</source>
        <translation>Spajanje s proxy poslužiteljem je odbijeno</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="275"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Proxy server je prerano prekinuo spajanje</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="277"/>
        <source>The proxy host name was not found</source>
        <translation>Ime proxy računala nije nađeno</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="279"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Spajanje prema proxyju je isteklo ili proxy nije na vrijeme odgovorio na poslani zahtjev</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="281"/>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>Proxy zahtjeva autentifikaciju kako bi prihvatio zahtjev, ali nije prihvatio ponuđene vjerodajnice</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="283"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>Pristup udaljenom sadržaju je odbijen (401)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="285"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Tražena operacija nad udaljenim sadržajem nije dopuštena</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="287"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>Udaljeni sadržaj nije nađen na poslužitelju (404)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="289"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Udaljeni poslužitelj zahtjeva autentifikaciju kako bi dostavio sadržaj, ali pružene vjerodajnice nisu prihvaćene</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="291"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>Network Access API ne može prihvatiti zahtjev jer protokol nije poznat</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="293"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Tražena operacija je neispravna za ovaj protokol</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="295"/>
        <source>An unknown network-related error was detected</source>
        <translation>Otkrivena je nepoznata greška vezana za mrežu</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="297"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Otkrivena je nepoznata greška vezana za proxy</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="299"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Otkrivena je nepoznata greška vezana za udaljeni sadržaj </translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="301"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Otkriven je kvar u protokolu</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="303"/>
        <source>Unknown error</source>
        <translation>Nepoznata greška</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../executionlog.ui" line="27"/>
        <source>General</source>
        <translation>Općenito</translation>
    </message>
    <message>
        <location filename="../executionlog.ui" line="33"/>
        <source>Blocked IPs</source>
        <translation>Blokirani IP-ovi</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation>RSS kanali</translation>
    </message>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation>Nepročitano</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <location filename="../headlessloader.h" line="55"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="56"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>kako bi kontrolirali qBittorrent, pristupite web sučelju na http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="57"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Administratorsko korisničko ime na web sučelju je: %1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="60"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Adminstratorska lozinka web sučelja ostaje zadana: %1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="61"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>To je sigurnosni rizik. Uzmite u obzir promjenu lozinke u postavkama programa.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <location filename="../webui/httpconnection.cpp" line="195"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Vaša IP adresa je zabranjena nakon previše neuspjelih pokušaja ovjere.</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/httpserver.cpp" line="110"/>
        <source>File</source>
        <translation>Datoteka</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="111"/>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="112"/>
        <source>Help</source>
        <translation>Pomoć</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="113"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Preuzmi torrente s njihovih URL-ova ili Magnet linka</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="114"/>
        <source>Only one link per line</source>
        <translation>Samo jedan link po liniji</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="115"/>
        <source>Download local torrent</source>
        <translation>Preuzmi lokalni torent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="116"/>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Torrent datoteke su ispravno dodane popisu preuzimanja.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="117"/>
        <source>Point to torrent file</source>
        <translation>Istakni torrent datoteku</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="118"/>
        <source>Download</source>
        <translation>Preuzmi</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="119"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Jeste li sigurni da želite izbrisati odabrane torrente s popisa transfera i čvrstog diska?</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="120"/>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Limit brzine preuzimanja mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="121"/>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Limit brzine slanja mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="122"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Limit najvećeg broja spajanja mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="123"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Limit najvećeg broja spajanja po torrentu mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="124"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Limit najvećeg broja priključnica po torrentu mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="125"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Nije moguće spremiti postavke programa. qBittorrent je vjerojatno nedostupan.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="126"/>
        <source>Language</source>
        <translation>Jezik</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="127"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Preuzeto</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="128"/>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Port korišten za dolazne veze mora biti veći od 1024 i manji od 65535.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="129"/>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Port korišten za web sučelje mora biti veći od 1024 i manji od 65535.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="130"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Korisničko ime web sučelja mora imati najmanje 3 znaka.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="131"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Lozinka web sučelja mora imati najmanje 3 znaka.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="132"/>
        <source>Save</source>
        <translation>Spremi</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="133"/>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent klijent nije dostupan</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="134"/>
        <source>HTTP Server</source>
        <translation>HTTP poslužitelj</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="135"/>
        <source>The following parameters are supported:</source>
        <translation>Podržani su sljedeći parametri:</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="136"/>
        <source>Torrent path</source>
        <translation>Putanja torrenta</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="137"/>
        <source>Torrent name</source>
        <translation>Ime torrenta</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="138"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent je bio ugašen.</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <location filename="../main.cpp" line="109"/>
        <source>Legal Notice</source>
        <translation>Pravna napomena</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="110"/>
        <location filename="../main.cpp" line="121"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent je program za dijeljenje datoteka. Kada pokrenete torrent, njegovi podaci bit će rapoloživi drugima. To znači da će drugi moći preuzimati datoteke i s vašeg računala. Za bilo koji sadržaj koji dijelite isključivo ste vi odgovorni.

Neće biti daljnjih napomena.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="111"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pritisnite %1 tipku za prihvaćanje i nastavak ...</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="122"/>
        <source>Legal notice</source>
        <translation>Napomena</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="123"/>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="124"/>
        <source>I Agree</source>
        <translation>Slažem se</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../lineedit/src/lineedit.cpp" line="30"/>
        <source>Clear the text</source>
        <translation>Izbriši tekst</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../loglistwidget.cpp" line="47"/>
        <source>Copy</source>
        <translation>Kopiraj</translation>
    </message>
    <message>
        <location filename="../loglistwidget.cpp" line="48"/>
        <source>Clear</source>
        <translation>Izbriši</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="37"/>
        <source>&amp;Edit</source>
        <translation>Ur&amp;edi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="61"/>
        <source>&amp;Tools</source>
        <translation>Ala&amp;ti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="82"/>
        <source>&amp;File</source>
        <translation>&amp;Datoteka</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="50"/>
        <source>&amp;Help</source>
        <translation>&amp;Pomoć</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="91"/>
        <source>&amp;View</source>
        <translation>Po&amp;gled</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="155"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opcije ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="165"/>
        <source>&amp;Resume</source>
        <translation>Nastavi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="321"/>
        <source>R&amp;esume All</source>
        <translation>Nastavi sve</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="194"/>
        <source>Torrent &amp;creator</source>
        <translation>&amp;Kreator torrenta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="248"/>
        <location filename="../mainwindow.ui" line="251"/>
        <source>Alternative speed limits</source>
        <translation>Alternativni limiti brzine</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="259"/>
        <source>Top &amp;tool bar</source>
        <translation>Gornja ala&amp;tna traka</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="262"/>
        <source>Display top tool bar</source>
        <translation>Prikaži gornju alatnu traku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="270"/>
        <source>&amp;Speed in title bar</source>
        <translation>Brzina u na&amp;slovnoj traci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="273"/>
        <source>Show transfer speed in title bar</source>
        <translation>Pokaži brzinu transfera u naslovnoj traci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>&amp;About</source>
        <translation>&amp;O</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="142"/>
        <source>&amp;Add torrent file...</source>
        <translation>Dod&amp;aj torrent datoteku ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="147"/>
        <location filename="../mainwindow.ui" line="150"/>
        <source>Exit</source>
        <translation>Izlaz</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="170"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pauziraj</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="175"/>
        <source>&amp;Delete</source>
        <translation>Iz&amp;briši</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <source>P&amp;ause All</source>
        <translation>P&amp;auziraj sve</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="184"/>
        <source>Visit &amp;Website</source>
        <translation>Posjeti &amp;web stranicu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="65"/>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Akcije nakon što preuzimanja završe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="189"/>
        <source>Add &amp;link to torrent...</source>
        <translation>Dodaj &amp;link torrentu ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="199"/>
        <source>Report a &amp;bug</source>
        <translation>Prijavi g&amp;rešku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="204"/>
        <source>Set upload limit...</source>
        <translation>Podesi limit slanja ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Set download limit...</source>
        <translation>Podesi limit preuzimanja ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="214"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentacija</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="219"/>
        <source>Set global download limit...</source>
        <translation>Podesi globalni limit preuzimanja ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="224"/>
        <source>Set global upload limit...</source>
        <translation>Podesi globalni limit slanja ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="281"/>
        <source>&amp;RSS reader</source>
        <translation>&amp;RSS čitač</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="289"/>
        <source>Search &amp;engine</source>
        <translation>&amp;Tražilica</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="345"/>
        <source>Exit qBittorrent</source>
        <translation>Izlaz iz qBittorrenta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="353"/>
        <source>Suspend system</source>
        <translation>Suspendiranje računala</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="361"/>
        <source>Hibernate system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="369"/>
        <source>Shutdown system</source>
        <translation>Isključivanje računala</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="377"/>
        <source>Disabled</source>
        <translation>Onemogućeno</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="382"/>
        <location filename="../mainwindow.cpp" line="1268"/>
        <source>Show</source>
        <translation>Prikaži</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="397"/>
        <location filename="../mainwindow.cpp" line="1413"/>
        <source>Check for updates</source>
        <translation type="unfinished">Provjeri ažuriranja</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="400"/>
        <location filename="../mainwindow.cpp" line="1414"/>
        <source>Check for program updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="297"/>
        <source>Lock qBittorrent</source>
        <translation>Zaključaj qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="305"/>
        <source>Import existing torrent...</source>
        <translation>Uvezi postojeći torrent ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="308"/>
        <source>Import torrent...</source>
        <translation>Uvezi torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="313"/>
        <source>Donate money</source>
        <translation>Donirajte novac</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="316"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Ako vam se sviđa qBittorrent donirajte!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="334"/>
        <source>Execution &amp;Log</source>
        <translation>Dnevnik izvršavanja</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="337"/>
        <location filename="../mainwindow.cpp" line="1442"/>
        <source>Execution Log</source>
        <translation>Dnevnik izvršavanja</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Decrease priority</source>
        <translation>Smanji prioritet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="237"/>
        <source>Increase priority</source>
        <translation>Povećaj prioritet</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="157"/>
        <source>Set the password...</source>
        <translation>Postavi lozinku ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="159"/>
        <location filename="../mainwindow.cpp" line="423"/>
        <source>Clear the password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="194"/>
        <source>Transfers</source>
        <translation>Transferi</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <source>Torrent file association</source>
        <translation>Pridruživanje torrent datoteka</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="321"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent nije zadana aplikacija za otvaranje torrent datoteka ili Magnet linkova.
Želite li pridružiti qBittorrent torrent datotekama i Magnet linkovima?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="408"/>
        <location filename="../mainwindow.cpp" line="434"/>
        <location filename="../mainwindow.cpp" line="701"/>
        <source>UI lock password</source>
        <translation>Lozinka zaključavanja sučelja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="408"/>
        <location filename="../mainwindow.cpp" line="434"/>
        <location filename="../mainwindow.cpp" line="701"/>
        <source>Please type the UI lock password:</source>
        <translation>Upišite  lozinku zaključavanja sučelja:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="412"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Lozinka mora imati najmanje 3 znaka</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="418"/>
        <source>Password update</source>
        <translation>Ažuriranje lozinke</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="418"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>Lozinka zaključavanja sučelja je uspješno ažurirana</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="423"/>
        <source>Are you sure you want to clear the password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="450"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="466"/>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="476"/>
        <source>Transfers (%1)</source>
        <translation>Transferi (%1)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="552"/>
        <source>Download completion</source>
        <translation>Preuzimanje završeno</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="552"/>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>Datoteka %1 je preuzeta.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="558"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>I/O greška</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="558"/>
        <source>An I/O error occurred for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Dogodila se I/O greška za torrent %1
Razlog: %2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="615"/>
        <source>Recursive download confirmation</source>
        <translation>Potvrda rekurzivnog preuzimanja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="615"/>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Torrent %1 sadrži torrent datoteke. Želite li nastaviti s preuzimanjem?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="616"/>
        <location filename="../mainwindow.cpp" line="797"/>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="617"/>
        <location filename="../mainwindow.cpp" line="796"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="618"/>
        <source>Never</source>
        <translation>Nikad</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="632"/>
        <source>Url download error</source>
        <translation>Greška prilikom preuzimanja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="632"/>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Nije moguće preuzeti datoteku sa: %1, razlog: %2.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="643"/>
        <source>Global Upload Speed Limit</source>
        <translation>Globalni limit brzine slanja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="662"/>
        <source>Global Download Speed Limit</source>
        <translation>Globalni limit brzine preuzimanja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1171"/>
        <source>[D: %1/s, U: %2/s] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[P: %1/s, S: %2/s] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1353"/>
        <source>Missing Python Interpreter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1354"/>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1398"/>
        <source>A new version is available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1399"/>
        <source>A new version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1408"/>
        <source>There isn&apos;t a new version available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1409"/>
        <source>There isn&apos;t a new version of qBittorrent available on Sourceforge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1510"/>
        <source>Checking for updates...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1511"/>
        <source>Already checking for program updates in the background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1575"/>
        <source>Download error</source>
        <translation type="unfinished">Greška prilikom preuzimanja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1575"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="412"/>
        <location filename="../mainwindow.cpp" line="714"/>
        <source>Invalid password</source>
        <translation>Neispravna lozinka</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="714"/>
        <source>The password is invalid</source>
        <translation>Lozinka nije ispravna</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1268"/>
        <source>Hide</source>
        <translation>Sakrij</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="793"/>
        <source>Exiting qBittorrent</source>
        <translation>Izlaz iz qBittorrenta</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="794"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Neke datoteke još se prenose.
Jeste li sigurni da želite zatvoriti qBittorrent?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="798"/>
        <source>Always</source>
        <translation>Uvijek</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="950"/>
        <source>Open Torrent Files</source>
        <translation>Otvori torrent datoteke</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="951"/>
        <source>Torrent Files</source>
        <translation>Torrent datoteke</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1038"/>
        <source>Options were saved successfully.</source>
        <translation>Opcije su uspješno spremljene.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1164"/>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Brzina preuzimanja: %1 KiB/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1160"/>
        <location filename="../mainwindow.cpp" line="1166"/>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Brzina slanja: %1 KiB/s</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <location filename="../properties/peeraddition.h" line="94"/>
        <source>Invalid IP</source>
        <translation>Neispravan IP</translation>
    </message>
    <message>
        <location filename="../properties/peeraddition.h" line="95"/>
        <source>The IP you provided is invalid.</source>
        <translation>IP koji ste pribavili nije ispravan.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <location filename="../properties/peerlistdelegate.h" line="64"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="65"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="66"/>
        <source>Port</source>
        <translation type="unfinished">Port</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="67"/>
        <source>Flags</source>
        <translation>Zastave</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="68"/>
        <source>Connection</source>
        <translation>Spajanje</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="69"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klijent</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="70"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Napredak</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="71"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Brzina preuzimanja</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="72"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Brzina slanja</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="73"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Preuzeto</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="74"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Poslano</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="160"/>
        <source>Add a new peer...</source>
        <translation>Dodaj novi peer ...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="169"/>
        <source>Copy IP</source>
        <translation>Kopiraj IP</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="171"/>
        <source>Limit download rate...</source>
        <translation>Limitiraj brzinu preuzimanja ...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="172"/>
        <source>Limit upload rate...</source>
        <translation>Limitiraj brzinu slanja ...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="174"/>
        <source>Ban peer permanently</source>
        <translation>Trajno isključi peer</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="185"/>
        <location filename="../properties/peerlistwidget.cpp" line="187"/>
        <source>Peer addition</source>
        <translation>Dodavanje peerova</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="185"/>
        <source>The peer was added to this torrent.</source>
        <translation>Peer je dodan ovom torrentu.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="187"/>
        <source>The peer could not be added to this torrent.</source>
        <translation>Peer ne može biti dodan ovom torrentu.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="218"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Jeste li sigurni? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="218"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Jeste li sigurni da želite trajno isključiti odabrane peerove?</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="219"/>
        <source>&amp;Yes</source>
        <translation>&amp;Da</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="219"/>
        <source>&amp;No</source>
        <translation>&amp;Ne</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="226"/>
        <source>Manually banning peer %1...</source>
        <translation>Ručno isključivanje peera %1 ...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="250"/>
        <source>Upload rate limiting</source>
        <translation>Limitiranje brzine slanja</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="284"/>
        <source>Download rate limiting</source>
        <translation>Limitiranje brzine preuzimanja</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="471"/>
        <source>interested(local) and choked(peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="477"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="486"/>
        <source>interested(peer) and choked(local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="492"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="500"/>
        <source>optimistic unchoke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="507"/>
        <source>peer snubbed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="514"/>
        <source>incoming connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="521"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="528"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="535"/>
        <source>peer from PEX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="542"/>
        <source>peer from DHT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="549"/>
        <source>encrypted traffic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="556"/>
        <source>encrypted handshake</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="571"/>
        <source>peer from LSD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../preferences/options.ui" line="93"/>
        <source>Downloads</source>
        <translation>Preuzimanja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="104"/>
        <source>Connection</source>
        <translation>Spajanja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="115"/>
        <source>Speed</source>
        <translation>Brzina</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="137"/>
        <source>Web UI</source>
        <translation>Web sučelje</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="148"/>
        <source>Advanced</source>
        <translation>Napredno</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="224"/>
        <source>(Requires restart)</source>
        <translation>(Zahtjeva ponovno pokretanje)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="258"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Koristi obojene naizmjenične redove</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="300"/>
        <location filename="../preferences/options.ui" line="326"/>
        <source>Start / Stop Torrent</source>
        <translation>Započni / Zaustavi torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="310"/>
        <location filename="../preferences/options.ui" line="336"/>
        <source>No action</source>
        <translation>Nema radnji</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="697"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Pridodaj .!qB proširenje nedovršenim datotekama</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="800"/>
        <source>Copy .torrent files to:</source>
        <translation>Kopiraj .torrent datoteke u:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1005"/>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Podržani su sljedeći parametri:
&lt;ul&gt;
&lt;li&gt;%f: Putanja torrenta&lt;/li&gt;
&lt;li&gt;%n: Ime torrenta&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1119"/>
        <source>Connections Limits</source>
        <translation>Limiti spajanja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1272"/>
        <source>Proxy Server</source>
        <translation>Proxy poslužitelj</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1529"/>
        <source>Global Rate Limits</source>
        <translation>Globalni limiti brzine</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1647"/>
        <source>Apply rate limit to uTP connections</source>
        <translation>Primijeni limit brzine za uTP spajanja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1654"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Primijeni limit brzine za dodatni promet</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1667"/>
        <source>Alternative Global Rate Limits</source>
        <translation>Alternativni globalni limiti brzine</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1773"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Planiraj korištenje alternativnih limita brzine</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2039"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Omogući lokalno otkrivanje peerova</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2051"/>
        <source>Encryption mode:</source>
        <translation>Način kriptiranja:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2059"/>
        <source>Prefer encryption</source>
        <translation>Preferiraj kriptiranje</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2064"/>
        <source>Require encryption</source>
        <translation>Zahtjevaj kriptiranje</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2069"/>
        <source>Disable encryption</source>
        <translation>Onemogući kriptiranje</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2101"/>
        <source> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Više informacija&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2144"/>
        <source>Maximum active downloads:</source>
        <translation>Najviše aktivnih preuzimanja:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2164"/>
        <source>Maximum active uploads:</source>
        <translation>Najviše aktivnih slanja:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2184"/>
        <source>Maximum active torrents:</source>
        <translation>Najviše aktivnih torrenta:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="533"/>
        <source>When adding a torrent</source>
        <translation>Kada dodajete torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="79"/>
        <location filename="../preferences/options.ui" line="82"/>
        <source>Behavior</source>
        <translation>Ponašanje</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="188"/>
        <source>Language</source>
        <translation>Jezik</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="549"/>
        <source>Display torrent content and some options</source>
        <translation>Prikaži sadržaj torrenta i neke opcije</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1055"/>
        <source>Port used for incoming connections:</source>
        <translation>Port korišten za dolazna spajanja:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1075"/>
        <source>Random</source>
        <translation>Nasumično</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1125"/>
        <source>Global maximum number of connections:</source>
        <translation>Globalni najveći broj spajanja:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1151"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Najveći broj spajanja po torrentu:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1174"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Najveći broj priključnica slanja po torrentu:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1547"/>
        <location filename="../preferences/options.ui" line="1702"/>
        <source>Upload:</source>
        <translation>Slanje:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1583"/>
        <location filename="../preferences/options.ui" line="1729"/>
        <source>Download:</source>
        <translation>Preuzimanje:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1576"/>
        <location filename="../preferences/options.ui" line="1609"/>
        <location filename="../preferences/options.ui" line="1722"/>
        <location filename="../preferences/options.ui" line="1749"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="767"/>
        <source>Remove folder</source>
        <translation>Ukloni mapu</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1817"/>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>do</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1872"/>
        <source>Every day</source>
        <translation>Svaki dan</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1877"/>
        <source>Week days</source>
        <translation>Radni dani</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1882"/>
        <source>Week ends</source>
        <translation>Dani vikenda</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1982"/>
        <source>DHT port:</source>
        <translation>DHT port:</translation>
    </message>
    <message utf8="true">
        <location filename="../preferences/options.ui" line="2023"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Razmjeni peerove s kompatibilnim Bittorrent klijentima (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1314"/>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1293"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1280"/>
        <source>Type:</source>
        <translation>Vrsta:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="20"/>
        <location filename="../preferences/options.ui" line="1631"/>
        <source>Options</source>
        <translation>Opcije</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="274"/>
        <source>Action on double-click</source>
        <translation>Radnja na dvostruki klik</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="283"/>
        <source>Downloading torrents:</source>
        <translation>Preuzimanje torrenta:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="305"/>
        <location filename="../preferences/options.ui" line="331"/>
        <source>Open destination folder</source>
        <translation>Otvori odredišnu mapu</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="318"/>
        <source>Completed torrents:</source>
        <translation>Završeni torrenti:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="350"/>
        <source>Desktop</source>
        <translation>Radna površina</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="363"/>
        <source>Show splash screen on start up</source>
        <translation>Prikaži najavni ekran kod pokretanja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="373"/>
        <source>Start qBittorrent minimized</source>
        <translation>Pokreni qBittorrent minimiziranog</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="399"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimiziraj qBittorrent u prostor obavijesti</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="409"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Zatvori qBittorrent u prostor obavijesti</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="418"/>
        <source>Tray icon style:</source>
        <translation>Stil ikone na sistemskoj traci:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="426"/>
        <source>Normal</source>
        <translation>Uobičajeno</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="431"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochrome (Tamna tema)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="436"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monochrome (Svijetla tema)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="380"/>
        <source>Ask for program exit confirmation</source>
        <translation>Traži potvrdu za zatvaranje programa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="196"/>
        <source>User Interface Language:</source>
        <translation>Jezik korisničkog sučelja:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="252"/>
        <source>Transfer List</source>
        <translation>Popis transfera</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="356"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Pokreni qBittorrent kod podizanja Windowsa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="390"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Prikaži ikonu qBittorrenta u prostoru obavijesti</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="449"/>
        <source>File association</source>
        <translation>Pridruživanje datoteka</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="455"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Koristi qBittorrent za .torrent datoteke</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="462"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Koristi qBittorrent za magnetne linkove</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="475"/>
        <source>Power Management</source>
        <translation>Upravljanje energijom</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="481"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Spriječi stanje mirovanja kada su torrenti aktivni</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="542"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Ne započinji preuzimanje automatski</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="558"/>
        <source>Bring torrent dialog to the front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="580"/>
        <source>Hard Disk</source>
        <translation>Tvrdi disk</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="586"/>
        <source>Save files to location:</source>
        <translation>Spremi datoteke ovdje:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="634"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Pridodaj oznaku torrenta u putanju spremanja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="644"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pridodijeli prostor na disku svim datotekama</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="651"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Drži nedovršene torrente u:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="704"/>
        <source>Automatically add torrents from:</source>
        <translation>Automatski dodaj torrente iz:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="757"/>
        <source>Add folder...</source>
        <translation>Dodaj mapu ...</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="849"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Kopiraj torrent datoteke završenih preuzimanja u:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="905"/>
        <source>Email notification upon download completion</source>
        <translation>Obavijesti e-poštom prilikom završetka preuzimanja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="919"/>
        <source>Destination email:</source>
        <translation>Odredišna adresa e-pošte:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="929"/>
        <source>SMTP server:</source>
        <translation>SMPT poslužitelj:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="978"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Ovaj poslužitelj zahtijeva sigurnu vezu (SSL)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="990"/>
        <source>Run an external program on torrent completion</source>
        <translation>Pokreni eksterni program kod završavanja torrenta</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1047"/>
        <source>Listening Port</source>
        <translation>Osluškivanje porta</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1097"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Koristi UPnP / NAT-PMP port prosljeđivanje  s mojeg routera</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1107"/>
        <source>Use different port on each startup</source>
        <translation>Koristi drukčiji port kod svakog pokretanja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1233"/>
        <source>Global maximum number of upload slots:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1368"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>U drugom slučaju, proxy poslužitelj bit će korišten za spajanja trackera</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1371"/>
        <source>Use proxy for peer connections</source>
        <translation>Koristi proxy za spajanja peerova</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1443"/>
        <source>IP Filtering</source>
        <translation>IP filtriranje</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1484"/>
        <source>Reload the filter</source>
        <translation>Ponovno učitaj filter</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1637"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Omogući upravljanje propusnošću (uTP)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1790"/>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>iz</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1864"/>
        <source>When:</source>
        <translation>Kada:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1947"/>
        <source>Privacy</source>
        <translation>Privatnost</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1953"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Omogući DHT (decentralizirana mreža) kako bi se našlo još peerova</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1962"/>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Koristi drugi port za DHT i Bittorrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2026"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Omogući razmjenu peerova (PeX) kako bi se našlo još peerova</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2036"/>
        <source>Look for peers on your local network</source>
        <translation>Potraži peerove u vašoj lokalnoj mreži</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2094"/>
        <source>Enable anonymous mode</source>
        <translation>Omogući anonimni mod</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2243"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Ne računaj spore torrente u ovim limitima</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2264"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Seedaj torrente dok njihov omjer ne dosegne</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2293"/>
        <source>then</source>
        <translation>tada</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2304"/>
        <source>Pause them</source>
        <translation>Pauziraji ih</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2309"/>
        <source>Remove them</source>
        <translation>Ukloni ih</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2407"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Koristi UPnP / NAT-PMP za prosljeđivanje porta s mojeg routera</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2417"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Koristi HTTPS umjesto HTTP-a</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2460"/>
        <source>Import SSL Certificate</source>
        <translation>Uvezi SSL certifikat</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2513"/>
        <source>Import SSL Key</source>
        <translation>Uvezi SSl ključ</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2448"/>
        <source>Certificate:</source>
        <translation>Certifikat:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2501"/>
        <source>Key:</source>
        <translation>Ključ:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2535"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2580"/>
        <source>Bypass authentication for localhost</source>
        <translation>Zaobiđi autentifikaciju za localhosta</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2604"/>
        <source>Update my dynamic domain name</source>
        <translation>Ažuriraj moje dinamičko ime domene</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2616"/>
        <source>Service:</source>
        <translation>Servis:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2639"/>
        <source>Register</source>
        <translation>Registar</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2648"/>
        <source>Domain name:</source>
        <translation>Ime domene:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1288"/>
        <source>(None)</source>
        <translation>(Nijedno)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="126"/>
        <source>BitTorrent</source>
        <translation>Bittorrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1303"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1340"/>
        <location filename="../preferences/options.ui" line="2372"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="939"/>
        <location filename="../preferences/options.ui" line="1381"/>
        <location filename="../preferences/options.ui" line="2548"/>
        <source>Authentication</source>
        <translation>Ovjera</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="951"/>
        <location filename="../preferences/options.ui" line="1395"/>
        <location filename="../preferences/options.ui" line="2587"/>
        <location filename="../preferences/options.ui" line="2662"/>
        <source>Username:</source>
        <translation>Korisničko ime:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="961"/>
        <location filename="../preferences/options.ui" line="1415"/>
        <location filename="../preferences/options.ui" line="2594"/>
        <location filename="../preferences/options.ui" line="2676"/>
        <source>Password:</source>
        <translation>Lozinka:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2129"/>
        <source>Torrent Queueing</source>
        <translation>Red čekanja torrenta</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2253"/>
        <source>Share Ratio Limiting</source>
        <translation>Limitiranje omjera djeljenja</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2358"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Omogući web korisničko sučelje (Udaljeno upravljanje)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1298"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1455"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Putanja filtera (.dat, .p2p, .p2b):</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../previewselect.cpp" line="51"/>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="52"/>
        <source>Size</source>
        <translation>Veličina</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="53"/>
        <source>Progress</source>
        <translation>Napredak</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="80"/>
        <location filename="../previewselect.cpp" line="117"/>
        <source>Preview impossible</source>
        <translation>Pregled nije moguć</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="80"/>
        <location filename="../previewselect.cpp" line="117"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Oprostite, nije moguće pregledati datoteku</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../properties/proplistdelegate.h" line="108"/>
        <source>Not downloaded</source>
        <translation>Nije preuzeto</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="117"/>
        <location filename="../properties/proplistdelegate.h" line="162"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Uobičajen</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="111"/>
        <location filename="../properties/proplistdelegate.h" line="163"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Visok</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="105"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Miješani</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="114"/>
        <location filename="../properties/proplistdelegate.h" line="164"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Najviši</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../properties/proptabbar.cpp" line="45"/>
        <source>General</source>
        <translation>Općenito</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="50"/>
        <source>Trackers</source>
        <translation>Trackeri</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="54"/>
        <source>Peers</source>
        <translation>Peerovi</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="58"/>
        <source>HTTP Sources</source>
        <translation>HTTP izvori</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="62"/>
        <source>Content</source>
        <translation>Sadržaj</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../properties/propertieswidget.ui" line="346"/>
        <source>Save path:</source>
        <translation>Putanja za spremanje:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="438"/>
        <source>Torrent hash:</source>
        <translation>Torrent smjesa:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="206"/>
        <source>Share ratio:</source>
        <translation>Omjer dijeljenja:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="77"/>
        <location filename="../properties/propertieswidget.ui" line="223"/>
        <source>Downloaded:</source>
        <translation>Preuzeto:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="131"/>
        <source>Availability:</source>
        <translation>Dostupnost:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="166"/>
        <source>Transfer</source>
        <translation>Transfer</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="172"/>
        <source>Uploaded:</source>
        <translation>Poslano:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="274"/>
        <source>Wasted:</source>
        <translation>Izgubljeno:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="189"/>
        <source>UP limit:</source>
        <translation>Limit slanja:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="240"/>
        <source>DL limit:</source>
        <translation>Limit preuzimanja:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="257"/>
        <source>Connections:</source>
        <translation>Spajanja:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="291"/>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Aktivno:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="308"/>
        <source>Reannounce in:</source>
        <translation>Ponovno objavi u:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="334"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="392"/>
        <source>Created on:</source>
        <translation>Kreirano:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="481"/>
        <source>Pieces size:</source>
        <translation>Veličina djelića:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="524"/>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="668"/>
        <source>Torrent content:</source>
        <translation>Sadržaj torrenta:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="721"/>
        <source>Select All</source>
        <translation>Odaberi sve</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="728"/>
        <source>Select None</source>
        <translation>Ne odaberi ništa</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="761"/>
        <source>Normal</source>
        <translation>Uobičajen</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="766"/>
        <source>High</source>
        <translation>Visok</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="771"/>
        <source>Maximum</source>
        <translation>Najviši</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="776"/>
        <location filename="../properties/propertieswidget.ui" line="779"/>
        <source>Do not download</source>
        <translation>Ne preuzimaj</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="318"/>
        <location filename="../properties/propertieswidget.cpp" line="319"/>
        <source>this session</source>
        <translation>ova sesija</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="320"/>
        <location filename="../properties/propertieswidget.cpp" line="321"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="324"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedano za %1</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="328"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 najviše</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="423"/>
        <location filename="../properties/propertieswidget.cpp" line="449"/>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="423"/>
        <source>This file does not exist yet.</source>
        <translation>Ta datoteka još ne postoji.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="449"/>
        <source>This folder does not exist yet.</source>
        <translation>Ta mapa još ne postoji.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="462"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="463"/>
        <source>Open Containing Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="464"/>
        <source>Rename...</source>
        <translation>Preimenuj ...</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="473"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="519"/>
        <source>New Web seed</source>
        <translation>Novi web seed</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="525"/>
        <source>Remove Web seed</source>
        <translation>Ukloni web seed</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="527"/>
        <source>Copy Web seed URL</source>
        <translation>Kopiraj URL web seeda</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="528"/>
        <source>Edit Web seed URL</source>
        <translation>Uredi URL web seeda</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="553"/>
        <source>Rename the file</source>
        <translation>Preimenuj ovu datoteku</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="554"/>
        <source>New name:</source>
        <translation>Novo ime:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="558"/>
        <location filename="../properties/propertieswidget.cpp" line="589"/>
        <source>The file could not be renamed</source>
        <translation>Datoteka se ne može preimenovati</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="559"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Ovo ime datoteke sadrži zabranjene znakove. Izaberite druge.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="590"/>
        <location filename="../properties/propertieswidget.cpp" line="628"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Ovo ime već se koristi u toj mapi. Koristite drugo.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="627"/>
        <source>The folder could not be renamed</source>
        <translation>Mapa se ne može preimenovati</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="666"/>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Novi URL seed</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="667"/>
        <source>New url seed:</source>
        <translation>Novi URL seed:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="728"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="673"/>
        <location filename="../properties/propertieswidget.cpp" line="729"/>
        <source>This url seed is already in the list.</source>
        <translation>Taj URL seed je već na listi.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="721"/>
        <source>Web seed editing</source>
        <translation>Uređivanje web seeda</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="722"/>
        <source>Web seed URL:</source>
        <translation>URL web seeda:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="240"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="246"/>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 dostigao je najveći zadani omjer.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="241"/>
        <source>Removing torrent %1...</source>
        <translation>Uklanjanje torrenta %1 ...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="247"/>
        <source>Pausing torrent %1...</source>
        <translation>Pauziranje torrenta %1 ...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="413"/>
        <source>HTTP user agent is %1</source>
        <translation>Agent HTTP korisnika je %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="443"/>
        <source>Anonymous mode [ON]</source>
        <translation>Anonimni mod [UKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="445"/>
        <source>Anonymous mode [OFF]</source>
        <translation>Anonimni mod [ISKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="503"/>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Prijavljivanje IP adrese trackerima...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="555"/>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Podrška za DHT [UKLJUČENO], port: UDP/%1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="557"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="561"/>
        <source>DHT support [OFF]</source>
        <translation>Podrška za DHT [ISKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="565"/>
        <source>PeX support [ON]</source>
        <translation>Podrška za PeX [UKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="567"/>
        <source>PeX support [OFF]</source>
        <translation>Podrška za PeX [ISKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="570"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Potrebno je ponovno pokretanje za uključivanje/isključivanje podrške za PeX</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="578"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Podrška za otkrivanje lokalnih peerova [ISKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="590"/>
        <source>Encryption support [ON]</source>
        <translation>Podrška za kriptiranje [UKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="595"/>
        <source>Encryption support [FORCED]</source>
        <translation>Podrška za kriptiranje [PRISILNO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="600"/>
        <source>Encryption support [OFF]</source>
        <translation>Podrška za kriptiranje [ISKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="662"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Ugrađeni tracker [UKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="664"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Nije moguće pokrenuti ugrađeni tracker!</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="667"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Ugrađeni tracker [ISKLJUČENO]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="721"/>
        <source>The Web UI is listening on port %1</source>
        <translation>Web sučelje osluškuje na portu %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="723"/>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Greška web korisničkog sučelja - Nije moguće povezati web korisničko sučelje s portom %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="875"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; je uklonjena s popisa transfera i čvrstog diska.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="877"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; je uklonjena s popisa transfera.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="972"/>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; nije valjani magnet URI.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="988"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1144"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1149"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1151"/>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; je već na popisu preuzimanja.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1278"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1283"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; počinje iznova. (brzo)</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1817"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1819"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2008"/>
        <source>qBittorrent is trying to listen on any interface port: TCP/%1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2024"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2050"/>
        <source>qBittorrent is trying to listen on interface %1 port: TCP/%2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2054"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2527"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2532"/>
        <source>Attempting to move torrent: &apos;%1&apos; to path: &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2719"/>
        <source>qBittorrent is successfully listening on interface %1 port: TCP/%2</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2732"/>
        <source>qBittorrent failed listening on interface %1 port: TCP/%2. Reason: %3</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2762"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="3019"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Uspješno razrješen dani IP filter: Primjenjena su %1 pravila.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="3025"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Greška: Razrješavanje danog IP filtera nije uspjelo.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1069"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1280"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1285"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; je dodan popisu preuzimanja.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="404"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Podrška za UPnP / NAT-PMP [UKLJUČENA]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="407"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Podrška za UPnP / NAT-PMP [ISKLJUČENA]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="575"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Podrška za lokalno otkrivanje peerova [UKLJUČENA]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1112"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1120"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1122"/>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Nije moguće dekodirati torrent datoteku: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1126"/>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Ta datoteka je i dalje neispravna ili nije torrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1167"/>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Greška: Torrent %1 ne sadrži nikakve datoteke.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1410"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1438"/>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Opaska: novi trackeri su dodani postojećem torrentu.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1468"/>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Opaska: novi URL seedovi dodani su postojećem torrentu.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2033"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>Definirano mrežno sučelje nije ispravno: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2236"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2238"/>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Rekurzivno preuzimanje datoteke %1 ugrađeno u torrent %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2322"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2324"/>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Nije moguće dekodirati %1 torrent datoteku.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2272"/>
        <source>Torrent name: %1</source>
        <translation>Ime torrenta: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2273"/>
        <source>Torrent size: %1</source>
        <translation>Veličina torrenta: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2274"/>
        <source>Save path: %1</source>
        <translation>Putanja spremanja: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2275"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrent je preuzet u %1.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2276"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Hvala vam što ste koristili qBittorrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2279"/>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 je preuzet</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2593"/>
        <source>An I/O error occurred, &apos;%1&apos; paused.</source>
        <translation>Dogodila se I/O greška. &apos;%1&apos; pauziran.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2594"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2708"/>
        <source>Reason: %1</source>
        <translation>Razlog: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2672"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapiranje porta nije uspjelo, poruka: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2677"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapiranje porta je uspjelo, poruka: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2703"/>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Veličine datoteka se ne slažu za torrent %1, tako da će biti pauziran.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2707"/>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Brzi ponovni početak je odbijen za torrent %1, ponovna provjera ...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2713"/>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Traženje URL seeda nije uspjelo za URL: %1, poruka: %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2845"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Preuzimanje &apos;%1&apos;, pričekajte ...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="31"/>
        <source>New subscription</source>
        <translation>Nova predbilježba</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="47"/>
        <location filename="../rss/rss.ui" line="195"/>
        <location filename="../rss/rss.ui" line="198"/>
        <source>Mark items read</source>
        <translation>Označi stavke kao pročitane</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="66"/>
        <source>Update all</source>
        <translation>Ažuriraj sve</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="95"/>
        <source>RSS Downloader...</source>
        <translation>RSS preuzimatelj</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="102"/>
        <source>Settings...</source>
        <translation>Postavke ...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="124"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrenti:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(dvostruki klik za preuzimanje )&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="158"/>
        <location filename="../rss/rss.ui" line="161"/>
        <source>Delete</source>
        <translation>Izbriši</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="166"/>
        <source>Rename...</source>
        <translation>Preimenuj ...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="169"/>
        <source>Rename</source>
        <translation>Preimenuj</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="174"/>
        <location filename="../rss/rss.ui" line="177"/>
        <source>Update</source>
        <translation>Ažuriraj</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="182"/>
        <source>New subscription...</source>
        <translation>Nova predbilježba ...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="187"/>
        <location filename="../rss/rss.ui" line="190"/>
        <source>Update all feeds</source>
        <translation>Ažuriraj sve kanale</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="203"/>
        <source>Download torrent</source>
        <translation>Preuzmi torrent</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="208"/>
        <source>Open news URL</source>
        <translation>Otvori news URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="213"/>
        <source>Copy feed URL</source>
        <translation>Kopiraj URL kanala</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="218"/>
        <source>New folder...</source>
        <translation>Nova mapa ...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="223"/>
        <source>Manage cookies...</source>
        <translation>Upravljaj kolačićima ...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="63"/>
        <source>Refresh RSS streams</source>
        <translation>Osvježi RSS strujanja</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../rss/rss_imp.cpp" line="204"/>
        <source>Please type a rss stream url</source>
        <translation>Utipkajte URL RSS strujanja</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="204"/>
        <source>Stream URL:</source>
        <translation>URL strujanja:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <location filename="../rss/rss_imp.cpp" line="247"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Jeste li sigurni? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <location filename="../rss/rss_imp.cpp" line="248"/>
        <source>&amp;Yes</source>
        <translation>&amp;Da</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <location filename="../rss/rss_imp.cpp" line="248"/>
        <source>&amp;No</source>
        <translation>&amp;Ne</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="157"/>
        <source>Please choose a folder name</source>
        <translation>Izaberite ime mape</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="157"/>
        <source>Folder name:</source>
        <translation>Ime mape:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="157"/>
        <source>New folder</source>
        <translation>Nova mapa</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="214"/>
        <source>This rss feed is already in the list.</source>
        <translation>Taj RSS kanal je već na popisu.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Jeste li sigurni da želite izbrisati te elemente s popisa?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="247"/>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Jeste li sigurni da želite izbrisati taj element s popisa?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="390"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Izaberite novo ime za taj RSS kanal</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="390"/>
        <source>New feed name:</source>
        <translation>Novo ime kanala:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="394"/>
        <source>Name already in use</source>
        <translation>Ime se već koristi</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="394"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>To ime već koristi neka druga stavka. Izaberite drugo.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="570"/>
        <source>Date: </source>
        <translation>Datum: </translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="573"/>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="622"/>
        <source>Unread</source>
        <translation>Nepročitano</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../rss/rssfeed.cpp" line="357"/>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Automatsko preuzimanje %1 torrenta sa %2 RSS kanala ...</translation>
    </message>
</context>
<context>
    <name>RssParser</name>
    <message>
        <location filename="../rss/rssparser.cpp" line="458"/>
        <source>Failed to open downloaded RSS file.</source>
        <translation>Neuspješno otvaranje preuzete RSS datoteke.</translation>
    </message>
    <message>
        <location filename="../rss/rssparser.cpp" line="495"/>
        <source>Invalid RSS feed at %1.</source>
        <translation>Neispravan RSS kanal na %1.</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Postavke RSS čitača</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Interval osvježavanja RSS kanala:</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>minute</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Najveći broj članaka po kanalu:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="102"/>
        <source>Watched Folder</source>
        <translation>Pregledana mapa</translation>
    </message>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="103"/>
        <source>Download here</source>
        <translation>Preuzmi ovdje</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="52"/>
        <source>All categories</source>
        <translation>Kategorije</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>Movies</source>
        <translation>Filmovi</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>TV shows</source>
        <translation>TV emisije</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>Music</source>
        <translation>Glazba</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Games</source>
        <translation>Igre</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Anime</source>
        <translation>Animirani</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Software</source>
        <translation>Softver</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Pictures</source>
        <translation>Slike</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="60"/>
        <source>Books</source>
        <translation>Knjige</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="154"/>
        <location filename="../searchengine/searchengine.cpp" line="173"/>
        <location filename="../searchengine/searchengine.cpp" line="174"/>
        <location filename="../searchengine/searchengine.cpp" line="435"/>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="185"/>
        <source>Empty search pattern</source>
        <translation>Prazan predložak potrage</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="185"/>
        <source>Please type a search pattern first</source>
        <translation>Prvo utipkajte predložak potrage</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="210"/>
        <location filename="../searchengine/searchengine.cpp" line="299"/>
        <source>Results</source>
        <translation>Rezultati</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="278"/>
        <source>Searching...</source>
        <translation>Potraga ...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="280"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="414"/>
        <source>Search Engine</source>
        <translation>Tražilica</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="414"/>
        <location filename="../searchengine/searchengine.cpp" line="429"/>
        <source>Search has finished</source>
        <translation>Potraga je gotova</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="420"/>
        <source>An error occurred during search...</source>
        <translation>Dogodila se greška za vrijeme potrage ...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="418"/>
        <location filename="../searchengine/searchengine.cpp" line="424"/>
        <source>Search aborted</source>
        <translation>Potraga je otkazana</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="427"/>
        <source>Search returned no results</source>
        <translation>Potraga vraćena bez rezultata</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="434"/>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Rezultati</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="470"/>
        <location filename="../searchengine/searchengine.cpp" line="476"/>
        <source>Unknown</source>
        <translation>Nije poznato</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="55"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="56"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Veličina</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="57"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Seederi</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="58"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leecheri</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="59"/>
        <source>Search engine</source>
        <translation>Tražilica</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="40"/>
        <source>Exit confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="41"/>
        <source>Exit now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="44"/>
        <source>Shutdown confirmation</source>
        <translation>Potvrda isključivanja</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="45"/>
        <source>Shutdown now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="99"/>
        <source>qBittorrent will now exit unless you cancel within the next %1 seconds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="102"/>
        <source>The computer will now be switched off unless you cancel within the next %1 seconds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="105"/>
        <source>The computer will now go to sleep mode unless you cancel within the next %1 seconds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.cpp" line="108"/>
        <source>The computer will now go to hibernation mode unless you cancel within the next %1 seconds.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../speedlimitdlg.h" line="84"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="50"/>
        <source>Alltime download:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="77"/>
        <source>Alltime upload:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="94"/>
        <source>Total waste (this session):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="114"/>
        <source>Cache statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="120"/>
        <source>Read cache Hits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="147"/>
        <source>Total buffers size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="157"/>
        <source>Performance statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="203"/>
        <source>Queued I/O jobs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="210"/>
        <source>Write cache overload:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="217"/>
        <source>Average time in queue (ms):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="224"/>
        <source>Read cache overload:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="231"/>
        <source>Total queued size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statsdialog.ui" line="279"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="179"/>
        <source>Connection status:</source>
        <translation>Status spajanja:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="179"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Nema izravnih spajanja. Ovo može značiti probleme u postavkama mreže.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="95"/>
        <location filename="../statusbar.h" line="186"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 čvorova</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="149"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>qBittorrent treba ponovno pokrenuti</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="159"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent je upravo ažuriran i treba ga ponovno pokrenuti kako bi promjene postale učinkovite.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="171"/>
        <location filename="../statusbar.h" line="176"/>
        <source>Connection Status:</source>
        <translation>Status spajanja:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="171"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Odspojeno. Ovo najčešće znači da qBittorrent nije uspio u očekivanju veze na odabranom portu za dolazna spajanja.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="176"/>
        <source>Online</source>
        <translation>Spojeno</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="192"/>
        <location filename="../statusbar.h" line="193"/>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="203"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Kliknite za prelazak na alternativne limite brzine</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="199"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Kliknite za prelazak na uobičajene limite brzine</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="212"/>
        <source>Manual change of rate limits mode. The scheduler is disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="224"/>
        <source>Global Download Speed Limit</source>
        <translation>Globalni limit brzine preuzimanja</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="249"/>
        <source>Global Upload Speed Limit</source>
        <translation>Globalni limit brzine slanja</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../torrentcontentmodel.cpp" line="41"/>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../torrentcontentmodel.cpp" line="41"/>
        <source>Size</source>
        <translation>Veličina</translation>
    </message>
    <message>
        <location filename="../torrentcontentmodel.cpp" line="42"/>
        <source>Progress</source>
        <translation>Napredak</translation>
    </message>
    <message>
        <location filename="../torrentcontentmodel.cpp" line="42"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="74"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Izaberite mapu koja će biti dodana torrentu</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="90"/>
        <source>Select a file to add to the torrent</source>
        <translation>Izaberite datoteku koja će biti dodana torrentu</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="113"/>
        <source>No input path set</source>
        <translation>Nije zadana ulazna putanja</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="113"/>
        <source>Please type an input path first</source>
        <translation>Upišite prvo ulaznu putanju</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="123"/>
        <source>Select destination torrent file</source>
        <translation>Izabrite odredišnu torrent datoteku</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="123"/>
        <source>Torrent Files</source>
        <translation>Torrent datoteke</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="150"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="164"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent creation</source>
        <translation>Kreiranje torrenta</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="150"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Kreiranje torrenta nije uspjelo. Razlog: %1</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="164"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Kreirana torrent datoteka nije ispravna. Neće biti dodana na popis preuzimanja.</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent was created successfully:</source>
        <translation>Torrent je uspješno kreiran:</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation>Uvoz torrenta</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="53"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Ovaj pomoćnik će vam olakšati dijeliti pomoću qBittorrenta torrent koji ste već preuzeli.</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="65"/>
        <source>Torrent file to import:</source>
        <translation>Torrent datoteka za uvoz:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="109"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="90"/>
        <source>Content location:</source>
        <translation>Lokacija sadržaja:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="121"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Preskoči korak provjere podataka i trenutno započni seedanje</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="131"/>
        <source>Import</source>
        <translation>Uvezi</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="68"/>
        <source>Torrent file to import</source>
        <translation>Torrent datoteka za uvoz</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="68"/>
        <source>Torrent files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="102"/>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1 datoteke</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="104"/>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Navedite lokaciju %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="139"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Istaknite lokaciju torrenta: %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="244"/>
        <source>Invalid torrent file</source>
        <translation>Neispravna torrent datoteka</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="244"/>
        <source>This is not a valid torrent file.</source>
        <translation>Ovo nije ispravna torrent datoteka.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="274"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="276"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Veličina</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="277"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Napredak</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="278"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="279"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Seedovi</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="280"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Peerovi</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="281"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Brzina preuzimanja</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="282"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Brzina slanja</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="283"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Omjer</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="284"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Preostalo vrijeme</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="285"/>
        <source>Label</source>
        <translation>Oznaka</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="286"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Dodano</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="287"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Dovršeno</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="288"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="289"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Limit preuzimanja</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="290"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Limit slanja</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="291"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation type="unfinished">Preuzeto</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="292"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation type="unfinished">Poslano</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="293"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="294"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Vrijeme aktivnosti</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="295"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="296"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation type="unfinished">Završeno</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="297"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../properties/trackerlist.cpp" line="64"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="65"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="66"/>
        <source>Peers</source>
        <translation>Peerovi</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="67"/>
        <source>Message</source>
        <translation>Poruka</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="201"/>
        <location filename="../properties/trackerlist.cpp" line="275"/>
        <source>Working</source>
        <translation>Radi</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="202"/>
        <source>Disabled</source>
        <translation>Onemogućeno</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="223"/>
        <source>This torrent is private</source>
        <translation>Ovaj torrent je privatan</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="279"/>
        <source>Updating...</source>
        <translation>Ažuriranje ...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="283"/>
        <source>Not working</source>
        <translation>Ne radi</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="286"/>
        <source>Not contacted yet</source>
        <translation>Još nije kontaktirano</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="377"/>
        <source>Tracker URL:</source>
        <translation>URL trackera:</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="377"/>
        <source>Tracker editing</source>
        <translation>Uređivanje trackera</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="383"/>
        <location filename="../properties/trackerlist.cpp" line="396"/>
        <source>Tracker editing failed</source>
        <translation>Uređivanje trackera neuspješno</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="383"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>Uneseni URL trackera nije ispravan.</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="396"/>
        <source>The tracker URL already exists.</source>
        <translation>URL trackera već postoji.</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="426"/>
        <source>Add a new tracker...</source>
        <translation>Dodaj novi tracker ...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="432"/>
        <source>Copy tracker url</source>
        <translation>Kopiraj URL trackera</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="433"/>
        <source>Edit selected tracker URL</source>
        <translation>Uredi URL odabranog trackera</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="438"/>
        <source>Force reannounce to all trackers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="431"/>
        <source>Remove tracker</source>
        <translation>Ukloni tracker</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Dijalog dodavanja trackera</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Popis trackera za dodati (jedan po liniji):</translation>
    </message>
    <message utf8="true">
        <location filename="../properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Popis URL-ova kompatibilan s µTorrentom:</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="79"/>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="79"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Greška prilikom pokušaja otvaranja preuzete datoteke.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="124"/>
        <source>No change</source>
        <translation>Bez promjene</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="124"/>
        <source>No additional trackers were found.</source>
        <translation>Nisu pronađeni dodatni trackeri.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="133"/>
        <source>Download error</source>
        <translation>Greška prilikom preuzimanja</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="133"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Popis trackera nije moguće preuzeti. Razlog: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../transferlistdelegate.h" line="94"/>
        <source>Downloading</source>
        <translation>Preuzimanje</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="97"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="100"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="104"/>
        <source>Paused</source>
        <translation>Pauzirano</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="108"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Na čekanju</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="112"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Seedanje</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="115"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Zastoj</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="119"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Provjeravanje</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="122"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="125"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="139"/>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="147"/>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="155"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedano za %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../transferlistfilterswidget.h" line="207"/>
        <source>Torrents</source>
        <translation>Torrenti</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="213"/>
        <source>Labels</source>
        <translation>Oznake</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="227"/>
        <location filename="../transferlistfilterswidget.h" line="309"/>
        <source>All</source>
        <translation>Sve</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="230"/>
        <location filename="../transferlistfilterswidget.h" line="310"/>
        <source>Downloading</source>
        <translation>Preuzimanja</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="233"/>
        <location filename="../transferlistfilterswidget.h" line="311"/>
        <source>Completed</source>
        <translation>Završeno</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="236"/>
        <location filename="../transferlistfilterswidget.h" line="312"/>
        <source>Paused</source>
        <translation>Pauzirano</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="239"/>
        <location filename="../transferlistfilterswidget.h" line="313"/>
        <source>Active</source>
        <translation>Aktivno</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="242"/>
        <location filename="../transferlistfilterswidget.h" line="314"/>
        <source>Inactive</source>
        <translation>Neaktivno</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="256"/>
        <location filename="../transferlistfilterswidget.h" line="493"/>
        <source>All labels</source>
        <translation>Sve označeno</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="259"/>
        <location filename="../transferlistfilterswidget.h" line="494"/>
        <source>Unlabeled</source>
        <translation>Neoznačeno</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="341"/>
        <source>Remove label</source>
        <translation>Ukloni oznaku</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="342"/>
        <source>Add label...</source>
        <translation>Dodaj oznaku ...</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="344"/>
        <source>Resume torrents</source>
        <translation>Nastavi s torrentima</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="345"/>
        <source>Pause torrents</source>
        <translation>Pauziraj torrente</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="346"/>
        <source>Delete torrents</source>
        <translation>Izbriši torrente</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="372"/>
        <source>New Label</source>
        <translation>Nova oznaka</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="372"/>
        <source>Label:</source>
        <translation>Oznaka:</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="377"/>
        <source>Invalid label name</source>
        <translation>Neispravno ime oznake</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="377"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Nemojte koristiti niti jedan poseban znak u imenu oznake.</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../transferlistwidget.cpp" line="563"/>
        <source>Column visibility</source>
        <translation>Vidljivost stupca</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="813"/>
        <source>Label</source>
        <translation>Oznaka</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="261"/>
        <source>Choose save path</source>
        <translation>Izaberi putanju spremanja</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="485"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Limitiranje brzine preuzimanja torrenta</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="518"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Limitiranje brzine slanja torrenta</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="551"/>
        <source>Recheck confirmation</source>
        <translation>Ponovno provjeri potvrđivanje</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="551"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Jeste li sigurni da želite ponovno provjeriti odabrani/e torrent(e)?</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="638"/>
        <source>New Label</source>
        <translation>Nova oznaka</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="638"/>
        <source>Label:</source>
        <translation>Oznaka:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="643"/>
        <source>Invalid label name</source>
        <translation>Neispravno ime oznake</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="643"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Nemojte koristiti niti jedan poseban znak u imenu oznake.</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="660"/>
        <source>Rename</source>
        <translation>Preimenovanje</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="660"/>
        <source>New name:</source>
        <translation>Novo ime:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="698"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Nastavi</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="700"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pauziraj</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="702"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Izbriši</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="704"/>
        <source>Preview file...</source>
        <translation>Pregledaj datoteke</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="706"/>
        <source>Limit share ratio...</source>
        <translation>Limit omjera djeljenja</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="708"/>
        <source>Limit upload rate...</source>
        <translation>Limitiraj brzinu slanja ...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="710"/>
        <source>Limit download rate...</source>
        <translation>Limitiraj brzinu preuzimanja ...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="712"/>
        <source>Open destination folder</source>
        <translation>Otvori odredišnu mapu</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="714"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Pomakni gore</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="716"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Pomakni dolje</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="718"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Na vrh</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="720"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Na dno</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="722"/>
        <source>Set location...</source>
        <translation>Postavi mjesto ...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="856"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="724"/>
        <source>Force recheck</source>
        <translation>Prisili ponovnu provjeru</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="726"/>
        <source>Copy magnet link</source>
        <translation>Kopiraj magnet link</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="728"/>
        <source>Super seeding mode</source>
        <translation>Način superseedanja</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="731"/>
        <source>Rename...</source>
        <translation>Preimenuj ...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="733"/>
        <source>Download in sequential order</source>
        <translation>Preuzmi u sekvencijskom poretku</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="736"/>
        <source>Download first and last piece first</source>
        <translation>Preuzmi prvi i zadnji djelić</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="814"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nova ...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="815"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Poništi</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Limitiranje omjera slanja/preuzimanja torrenta</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Koristi globalni limit omjera</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="23"/>
        <location filename="../updownratiodlg.ui" line="33"/>
        <location filename="../updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Ne podešavaj limit omjera</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Podesi limit omjera na</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <location filename="../main.cpp" line="87"/>
        <source>Usage:</source>
        <translation>Upotreba:</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="88"/>
        <source>displays program version</source>
        <translation>prikazuje verziju programa</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>disable splash screen</source>
        <translation>onemogućava najavni zaslon</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="92"/>
        <source>run in daemon-mode (background)</source>
        <translation>pokreni u deamon modu (pozadina)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="94"/>
        <source>displays this help message</source>
        <translation>prikazuje ovu poruku pomoći</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>changes the webui port (current: %1)</source>
        <translation>mijenja port web sučelja(trenutni: %1)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="96"/>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[datoteke ili URL-ovi]: preuzima torrente koje je korisnik dopustio (neobavezno)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../about_imp.h" line="54"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../about_imp.h" line="56"/>
        <source>Copyright ©2006-2013 The qBittorrent project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="58"/>
        <source>Home Page: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="60"/>
        <source>Bug Tracker: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="62"/>
        <source>Forum: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="65"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="82"/>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Zahvaljujem sljedećim ljudima koji su dobrovoljno preveli qBittorrent:</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="121"/>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Molim vas da me obavijestite ako želite prevesti qBittorrent na svoj jezik.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <location filename="../properties/peer.ui" line="20"/>
        <source>Peer addition</source>
        <translation>Dodavanje peerova</translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="36"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="59"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../login.ui" line="14"/>
        <location filename="../login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Ovjera trackera</translation>
    </message>
    <message>
        <location filename="../login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="86"/>
        <source>Login</source>
        <translation>Prijava</translation>
    </message>
    <message>
        <location filename="../login.ui" line="94"/>
        <source>Username:</source>
        <translation>Korisničko ime:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="117"/>
        <source>Password:</source>
        <translation>Lozinka:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="154"/>
        <source>Log in</source>
        <translation>Prijavi se</translation>
    </message>
    <message>
        <location filename="../login.ui" line="161"/>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Potvrda brisanja - qBittorrent</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Zapamti izbor</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Također izbriši datoteke i na čvrstom disku</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="296"/>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Alat za kreiranje torrenta</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="38"/>
        <source>Torrent file creation</source>
        <translation>Kreiranje torrent datoteke</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="60"/>
        <source>Add file</source>
        <translation>Dodaj datoteku</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="67"/>
        <source>Add folder</source>
        <translation>Dodaj mapu</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="48"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Datoteka ili mapa za dodati u torrent:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="78"/>
        <source>Tracker URLs:</source>
        <translation>URL-ovi trackera:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="88"/>
        <source>Web seeds urls:</source>
        <translation>URL-ovi web seedova:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="98"/>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="127"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Možete odvojiti grupe trackera praznom linijom.</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="148"/>
        <source>Piece size:</source>
        <translation>Veličina djelića:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="165"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="170"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="175"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="180"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="185"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="190"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="195"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="200"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="208"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="233"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privatno (neće biti distribuirano na DHT mreži ako je omogućeno)</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="240"/>
        <source>Start seeding after creation</source>
        <translation>Započni seedanje nakon kreiranja</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="250"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="289"/>
        <source>Create and save...</source>
        <translation>Kreiraj i spremi ...</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="260"/>
        <source>Progress:</source>
        <translation>Napredak:</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../downloadfromurldlg.ui" line="28"/>
        <source>Add torrent links</source>
        <translation>Dodaj linkove torrenta</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="55"/>
        <source>One per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="77"/>
        <source>Download</source>
        <translation>Preuzmi</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="84"/>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Preuzmi s URL-ova</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="97"/>
        <source>No URL entered</source>
        <translation>Nije unesen URL</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="97"/>
        <source>Please type at least one URL.</source>
        <translation>Upišite bar jedan URL.</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Tražilice</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation>Instalirane tražilice:</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <location filename="../searchengine/engineselect.ui" line="119"/>
        <source>Enabled</source>
        <translation>Omogućeno</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="78"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Nove tražilice možete naći ovdje: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="93"/>
        <source>Install a new one</source>
        <translation>Instaliraj novu</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="100"/>
        <source>Check for updates</source>
        <translation>Provjeri ažuriranja</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="107"/>
        <source>Close</source>
        <translation>Zatvori</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Uninstall</source>
        <translation>Deinstaliraj</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="175"/>
        <source>Uninstall warning</source>
        <translation>Upozorenje deinstalacije</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="175"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Neke tražilice ne mogu biti instalirane jer su već uključene u QBittorrent.
Samo one koje ste sami dodali mogu biti deinstalirane.
Međutim, te tražilice su bile onemogućene.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="177"/>
        <source>Uninstall success</source>
        <translation>Deinstalacija je uspjela</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="338"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="353"/>
        <source>Select search plugins</source>
        <translation>Izaberite tražilice</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="354"/>
        <source>qBittorrent search plugins</source>
        <translation>qBittorrentove tražilice</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="238"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="263"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="268"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="277"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="280"/>
        <source>Search plugin install</source>
        <translation>Instalacija tražilice</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="118"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="189"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="300"/>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="121"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="155"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="192"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="303"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="263"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="268"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="277"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="280"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="406"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="439"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="460"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="467"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="238"/>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Novija verzija %1 tražilice je već instalirana.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="406"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="439"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="460"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="467"/>
        <source>Search plugin update</source>
        <translation>Ažuriranje tražilice</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="439"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="460"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Oprostite, ali poslužitelj za ažuriranje trenutno nije raspoloživ.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="406"/>
        <source>All your plugins are already up to date.</source>
        <translation>Sve vaše tražilice su ažurirane.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="263"/>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 tražilica ne može biti ažurirana tako da ostaje stara verzija.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="268"/>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 tražilicu nije moguće instalirati.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="177"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Sve izabrane tražilice su uspješno deinstalirane</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="277"/>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 tražilica je uspješno ažurirana.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="280"/>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 tražilica je uspješno instalirana.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="338"/>
        <source>Invalid link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="467"/>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Oprostite, ali instalacija %1 tražilice nije uspjela.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="330"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="339"/>
        <source>New search engine plugin URL</source>
        <translation>Novi URL tražilice</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="331"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="340"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Informacija o rušenju</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../fs_utils.cpp" line="430"/>
        <location filename="../fs_utils.cpp" line="461"/>
        <location filename="../fs_utils.cpp" line="473"/>
        <source>Downloads</source>
        <translation>Preuzimanja</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../misc.cpp" line="76"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="77"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="78"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="79"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="80"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="276"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="421"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1s %2m</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="426"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2s</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="266"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Nije poznato</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="206"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent će sada isključiti računalo jer su sva preuzimanja završila.</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="412"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="416"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="246"/>
        <source>Working</source>
        <translation>Radi</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="249"/>
        <source>Updating...</source>
        <translation>Ažuriranje ...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="251"/>
        <source>Not working</source>
        <translation>Ne radi</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="251"/>
        <source>Not contacted yet</source>
        <translation>Još nije kontaktirano</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="309"/>
        <location filename="../webui/btjson.cpp" line="310"/>
        <source>this session</source>
        <translation>ova sesija</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="315"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedano za %1</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="317"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 najviše</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="385"/>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Preuzimanje: %1/s - Preuzeto: %2</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="386"/>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Slanje: %1/s - Poslano: %2</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1147"/>
        <location filename="../preferences/options_imp.cpp" line="1149"/>
        <source>Choose export directory</source>
        <translation>Izaberite direktorij za izvoz</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1189"/>
        <location filename="../preferences/options_imp.cpp" line="1191"/>
        <location filename="../preferences/options_imp.cpp" line="1206"/>
        <location filename="../preferences/options_imp.cpp" line="1208"/>
        <source>Choose a save directory</source>
        <translation>Izaberite direktorij za spremanje</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1171"/>
        <location filename="../preferences/options_imp.cpp" line="1173"/>
        <source>Choose an ip filter file</source>
        <translation>Izaberite datoteku za ip filtriranje</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1103"/>
        <source>Add directory to scan</source>
        <translation>Dodaj direktorij za skeniranje</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1109"/>
        <source>Folder is already being watched.</source>
        <translation>Mapa je već pregledana.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1112"/>
        <source>Folder does not exist.</source>
        <translation>Mapa ne postoji.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1115"/>
        <source>Folder is not readable.</source>
        <translation>Mapa nije čitljiva.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1124"/>
        <source>Failure</source>
        <translation>Neuspjeh</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1124"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Nije uspjelo dodavanje mape za skeniranje &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1171"/>
        <location filename="../preferences/options_imp.cpp" line="1173"/>
        <source>Filters</source>
        <translation>Filteri</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1251"/>
        <source>SSL Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1262"/>
        <source>SSL Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1293"/>
        <source>Parsing error</source>
        <translation>Greška razrješavanja</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1293"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Razrješavanje danog IP filtera nije uspjelo</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1295"/>
        <source>Successfully refreshed</source>
        <translation>Uspješno obnovljeno</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1295"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Uspješno razrješen dani IP filter: Primjenjena su %1 pravila.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1373"/>
        <source>Invalid key</source>
        <translation>Neispravan ključ</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1373"/>
        <source>This is not a valid SSL key.</source>
        <translation>To nije valjani SSl ključ.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1388"/>
        <source>Invalid certificate</source>
        <translation>Neispravan certifikat</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1388"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Ovo nije valjani SSL certifikat</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1397"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1400"/>
        <source>Time Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Izvor priključka</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Potraži izvor priključka:</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation>Lokalna datoteka</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation>Web link</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../preview.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Pregledaj odabir</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="38"/>
        <source>File preview</source>
        <translation>Pregled datoteke</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="54"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preview.ui" line="89"/>
        <source>Preview</source>
        <translation>Pregledaj</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="96"/>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="31"/>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="54"/>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="78"/>
        <source>Stopped</source>
        <translation>Zaustavljeno</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="110"/>
        <source>Download</source>
        <translation>Preuzmi</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="120"/>
        <source>Go to description page</source>
        <translation>Idi na stranicu opisa</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="140"/>
        <source>Search engines...</source>
        <translation>Tražilice ...</translation>
    </message>
</context>
</TS>
